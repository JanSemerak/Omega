Omega 
Jan Semerák
21.4.2024

Nastavení Databáze: Uživatel musí vlastnit program MySQL Workbench a následně se připojit na svůj MySQL server. Po připojení na server klikne uživatel nahoře v nabídce na možnost server a následně na data import. V data importu uživatel zaklikne možnost Import from Self-Contained File a pomocí tří teček úplně vpravo vybere sql soubor ve složce sqlexport v odevzdané alfě. Poté musí uživatel u možnosti Default schema to be Imported To kliknout na možnost new a vytvořit nové schéma. Poté je nutné mít dole možnost Dump Structure and Data a následně již uživatel může spustit Start Import
Pokud nebude fungovat import, uživatel vezme script.sql a vloží ho do mySQL a celý ho pomocí ctrl+a označí a stiskne blesk a měla by se vytvořit databáze

Instalace programu: Složka s programem se vloží na disk C: do složky Users do složky s názvem vašeho počítače a poté do složky PycharmProjects.

Spuštění programu: 1.uživatel otevře konfigurační soubor a nakonfiguruje program 
		   2.Uživatel spusti příkazový řádek
		   3.Pomocí příkazu cd cesta k souboru např: cd C:\Users\42072\PycharmProjects\omegaa\src se uživatel přesune do složky s projektem
		   4.pomocí příkazu pip install nainstaluje potřebné knihovny:tkinter, ttkthemes, ttkbootstrap, fpdf
		   5.poté co nainstalujete všechny potřebné knihovny uživatel zadá do příkazového řádku příkaz py (python). main.py a aplikce se zapne 

Ovládání programu: Jelikož je program okenní aplikace tak se program ovládá pouze klikáním myší na tlačítka a vyplnování políček klávesnicí

