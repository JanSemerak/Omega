import re
import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
from tkinter import messagebox
from DatabaseConnection import DatabaseConnection


class Pojistovna(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

    def pojistovna_button(self):
        """
        Tato metoda vytváří okno které obsahuje tabulku Pojistovna a tlačítka pro insert, update a delete tlačítko
        které okno zavře a do menu
        :return: nevrací nic
        """
        self.cursor.execute("SELECT pojistovna.id_pojistovna, pojistovna.nazev_pojistovna, pojistovna.ulice_pojistovna, pojistovna.mesto_pojistovna, pojistovna.cislo_popisne_pojistovna, pojistovna.psc_pojistovna FROM pojistovna")
        rows = self.cursor.fetchall()

        pojistovna = ThemedTk()
        pojistovna.title("pojistovna")
        pojistovna.geometry("1920x1080")
        pojistovna.configure(background="#282828")
        style = ttk.Style(pojistovna)
        style.theme_use("equilux")

        self.pojistovna_main_frame = tk.Frame(pojistovna)
        self.pojistovna_main_frame.grid(row=1, column=0, padx=150, pady=200)
        self.pojistovna_main_frame.configure(background="#282828")

        self.pojistovna = ttk.Label(self.pojistovna_main_frame, text="Tabulka pojistovna")
        self.pojistovna.grid(row=0)
        self.pojistovna.configure(background="#282828", padding=20, font=("Helvetica", 40, "bold"), foreground="white")

        self.table_frame = tk.Frame(self.pojistovna_main_frame)
        self.table_frame.grid(row=1, column=0, padx=10, pady=5)
        self.table_frame.configure(background="#282828")

        table = ttk.Treeview(self.table_frame, columns=(
            "nazev_pojistovna", "ulice_pojistovna", "mesto_pojistovna", "cislo_popisne_pojistovna", "psc_pojistovna"))

        table.heading("#0", text="ID")
        table.heading("nazev_pojistovna", text="nazev_pojistovna")
        table.heading("ulice_pojistovna", text="ulice_pojistovna")
        table.heading("mesto_pojistovna", text="mesto_pojistovna")
        table.heading("cislo_popisne_pojistovna", text="cislo_popisne_pojistovna")
        table.heading("psc_pojistovna", text="psc_pojistovna")

        for row in rows:
            table.insert("", "end", text=row[0], values=(row[1], row[2], row[3], row[4], row[5]))

        table.grid(row=1, pady=5, padx=210)

        def zavri_pojistovnu():
            pojistovna.destroy()

        self.button_frame = tk.Frame(self.pojistovna_main_frame)
        self.button_frame.grid(row=2, column=0, padx=0, pady=5)
        self.button_frame.configure(background="#282828")

        self.zpet_button_frame = tk.Frame(self.pojistovna_main_frame)
        self.zpet_button_frame.grid(row=3, column=0, padx=0, pady=5)
        self.zpet_button_frame.configure(background="#282828")

        insert_pojistovna = ttk.Button(self.button_frame, text="insert", command=self.insert_pojistovna_window)
        update_pojistovna = ttk.Button(self.button_frame, text="update", command=self.update_pojistovna_window)
        delete_pojistovna = ttk.Button(self.button_frame, text="delete", command=self.delete_pojistovna_window)
        zpet = ttk.Button(self.zpet_button_frame, text="zpet", command=zavri_pojistovnu)
        insert_pojistovna.grid(padx=5,pady=5, row=2, column=0)
        update_pojistovna.grid(padx=5,pady=5, row=2, column=1)
        delete_pojistovna.grid(padx=5,pady=5, row=2, column=2)
        zpet.grid(pady=5, row=5, column=0)

    def insert_pojistovna_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vložení záznamu do tabulky Pojistovna
        :return:nevrací nic
        """
        self.insert_pojistovna = ThemedTk()
        self.insert_pojistovna.title("insert_pojistovna")
        self.insert_pojistovna.geometry("400x350")
        self.insert_pojistovna.configure(background="#282828")
        style = ttk.Style(self.insert_pojistovna)
        style.theme_use("equilux")

        self.poj = ttk.Label(self.insert_pojistovna, text="Insert Pojistovna")
        self.poj.grid(row=0)
        self.poj.configure(background="#282828", padding=20, font=("Helvetica", 20, "bold"), foreground="white")

        self.insert_pojistovna_main_frame = tk.Frame(self.insert_pojistovna)
        self.insert_pojistovna_main_frame.grid(row=1, column=0, padx=0, pady=5)
        self.insert_pojistovna_main_frame.configure(background="#282828")

        self.nazev_pojistovna_frame = tk.Frame(self.insert_pojistovna_main_frame)
        self.nazev_pojistovna_frame.grid(row=0, column=0, pady=5, padx=5,sticky= "ew")
        self.nazev_pojistovna_frame.configure(background="#282828")

        self.nazev_pojistovna_label = ttk.Label(self.nazev_pojistovna_frame, text="nazev pojistovny:")
        self.nazev_pojistovna_label.grid(row=0, column=0, padx=5, pady=5,sticky= "w")
        self.nazev_pojistovna_label.configure(background="#282828", foreground="lightgray")

        self.nazev_pojistovna_entry = ttk.Entry(self.nazev_pojistovna_frame)
        self.nazev_pojistovna_entry.grid(row=0, column=1, padx=5, pady=5)

        self.ulice_pojistovna_frame = tk.Frame(self.insert_pojistovna_main_frame)
        self.ulice_pojistovna_frame.grid(row=1, column=0, pady=5, padx=5,sticky= "ew")
        self.ulice_pojistovna_frame.configure(background="#282828")

        self.ulice_pojistovna_label = ttk.Label(self.ulice_pojistovna_frame, text="ulice pojistovny:")
        self.ulice_pojistovna_label.grid(row=1, column=0, padx=5, pady=5,sticky= "w")
        self.ulice_pojistovna_label.configure(background="#282828", foreground="lightgray")

        self.ulice_pojistovna_entry = ttk.Entry(self.ulice_pojistovna_frame)
        self.ulice_pojistovna_entry.grid(row=1, column=1, padx=5, pady=5)

        self.mesto_pojistovna_frame = tk.Frame(self.insert_pojistovna_main_frame)
        self.mesto_pojistovna_frame.grid(row=2, column=0, pady=5, padx=5,sticky= "ew")
        self.mesto_pojistovna_frame.configure(background="#282828")

        self.mesto_pojistovna_label = ttk.Label(self.mesto_pojistovna_frame, text="mesto pojistovny:")
        self.mesto_pojistovna_label.grid(row=2, column=0, padx=5, pady=5,sticky= "w")
        self.mesto_pojistovna_label.configure(background="#282828", foreground="lightgray")

        self.mesto_pojistovna_entry = ttk.Entry(self.mesto_pojistovna_frame)
        self.mesto_pojistovna_entry.grid(row=2, column=1, padx=5, pady=5)

        self.cislo_popisne_pojistovna_frame = tk.Frame(self.insert_pojistovna_main_frame)
        self.cislo_popisne_pojistovna_frame.grid(row=3, column=0, pady=5, padx=5,sticky= "ew")
        self.cislo_popisne_pojistovna_frame.configure(background="#282828")

        self.cislo_popisne_pojistovna_label = ttk.Label(self.cislo_popisne_pojistovna_frame, text="cislo popisne pojistovny:")
        self.cislo_popisne_pojistovna_label.grid(row=3, column=0, padx=5, pady=5,sticky= "w")
        self.cislo_popisne_pojistovna_label.configure(background="#282828", foreground="lightgray")

        self.cislo_popisne_pojistovna_entry = ttk.Entry(self.cislo_popisne_pojistovna_frame)
        self.cislo_popisne_pojistovna_entry.grid(row=3, column=1, padx=5, pady=5)

        self.psc_pojistovna_frame = tk.Frame(self.insert_pojistovna_main_frame)
        self.psc_pojistovna_frame.grid(row=4, column=0, pady=5, padx=5,sticky= "ew")
        self.psc_pojistovna_frame.configure(background="#282828")

        self.psc_pojistovna_label = ttk.Label(self.psc_pojistovna_frame, text="psc pojistovny:")
        self.psc_pojistovna_label.grid(row=4, column=0, padx=5, pady=5,sticky= "w")
        self.psc_pojistovna_label.configure(background="#282828", foreground="lightgray")

        self.psc_pojistovna_entry = ttk.Entry(self.psc_pojistovna_frame)
        self.psc_pojistovna_entry.grid(row=4, column=1, padx=5, pady=5)

        self.odeslat_button = ttk.Button(self.insert_pojistovna, text="Odeslat", command=self.i_pojistovna)
        self.odeslat_button.grid(row=5, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.insert_pojistovna, text="Help", command=self.i_informace_pojistovna)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def update_pojistovna_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro upravení záznamu v tabulce Pojistovna
        :return:nevrací nic
        """
        self.update_pojistovna = ThemedTk()
        self.update_pojistovna.title("update pojistovna")
        self.update_pojistovna.geometry("360x210")
        self.update_pojistovna.configure(background="#282828")
        style = ttk.Style(self.update_pojistovna)
        style.theme_use("equilux")

        self.atribut = ttk.Label(self.update_pojistovna, text="atribut který chcete upravit v tabulce pojistovna:")
        self.atribut.grid(row=0, column=0, padx=1, pady=2)
        self.atribut.configure(background="#282828", foreground="lightgray")

        self.atribut = ["nazev_pojistovna", "ulice_pojistovna", "mesto_pojistovna", "cislo_popisne_pojistovna", "psc_pojistovna"]
        self.atribut_variable = tk.StringVar(self.update_pojistovna)
        self.atribut_variable.set(self.atribut[0])
        self.dropdown = ttk.OptionMenu(self.update_pojistovna, self.atribut_variable, *self.atribut)
        self.dropdown.grid(row=1, column=0, padx=1, pady=2)

        self.uprava_atributu = ttk.Label(self.update_pojistovna, text="na co chcete daný atribut opravit:")
        self.uprava_atributu.grid(row=2, column=0, padx=1, pady=2)
        self.uprava_atributu.configure(background="#282828", foreground="lightgray")

        self.uprava_atributu_entry = ttk.Entry(self.update_pojistovna)
        self.uprava_atributu_entry.grid(row=3, column=0, padx=1, pady=2)

        self.nazev_pojistovny = ttk.Label(self.update_pojistovna,text="nazev pojistovny u které chcete atribut upravit:")
        self.nazev_pojistovny.grid(row=4, column=0, padx=1, pady=2)
        self.nazev_pojistovny.configure(background="#282828", foreground="lightgray")

        self.nazev_pojistovny_entry = ttk.Entry(self.update_pojistovna)
        self.nazev_pojistovny_entry.grid(row=5, column=0, padx=1, pady=2)

        self.login_button = ttk.Button(self.update_pojistovna, text="Odeslat", command=self.u_pojistovna)
        self.login_button.grid(row=6, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.update_pojistovna, text="Help", command=self.u_informace_pojistovna)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)
    def delete_pojistovna_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vymazání záznamu z tabulky Pojistovna
        :return:nevrací nic
        """
        self.delete_pojistovna = ThemedTk()
        self.delete_pojistovna.title("delete pojistovna")
        self.delete_pojistovna.configure(background="#282828")
        style = ttk.Style(self.delete_pojistovna)
        style.theme_use("equilux")

        self.nazev_pojistovny = ttk.Label(self.delete_pojistovna, text="zadejte nazev pojistovny kterou chcete smazat:")
        self.nazev_pojistovny.grid(row=0, column=0, padx=1, pady=2)
        self.nazev_pojistovny.configure(background="#282828", foreground="lightgray")

        self.nazev_pojistovny_entry = ttk.Entry(self.delete_pojistovna)
        self.nazev_pojistovny_entry.grid(row=1, column=0, padx=1, pady=2)

        self.odeslat_button = ttk.Button(self.delete_pojistovna, text="Odeslat", command=self.d_pojistovna)
        self.odeslat_button.grid(row=2, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.delete_pojistovna, text="Help", command=self.d_informace_pojistovna)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def zavri_insert_pojistovna(self):
        """
        tato metoda zavře okno pro insert Pojistovna
        :return:nevrací nic
        """
        self.insert_pojistovna.destroy()

    def zavri_update_pojistovna(self):
        """
        tato metoda zavře okno pro update Pojistovna
        :return:nevrací nic
        """
        self.update_pojistovna.destroy()

    def zavri_delete_pojistovna(self):
        """
        tato metoda zavře okno pro delete Pojistovna
        :return:nevrací nic
        """
        self.delete_pojistovna.destroy()

    def i_informace_pojistovna(self):
        messagebox.showinfo("Info","Pro úspěšný insert vyplňte správně všechny kolonky")

    def u_informace_pojistovna(self):
        messagebox.showinfo("Info","Pro úspěšný update zvolte řádek, který chcete změnit a poté vyplňte správně kolonky")

    def d_informace_pojistovna(self):
        messagebox.showinfo("Info","Pro úspěšný delete vyplňte správně název")

    def i_pojistovna(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro insert Pojistovna ošetří je regurelníma výrazama a poté je
        vloží do insert statementu pokud se insert provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        pokud uživatel zadá určitý atribut který musí být pro každý záznam unikátní tak na neho vyskočí okénko že musí
        být daný atribut unikátní
        :return: nevrací nic
        """
        i_nazev_pojistovna = self.nazev_pojistovna_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_nazev_pojistovna):
            messagebox.showerror("chyba", "Pojistovna může obsahovat pouze písmena a mezery")
            raise ValueError('Pojistovna musí obsahovat pouze písmena a mezery')
        i_ulice_pojistovna = self.ulice_pojistovna_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_ulice_pojistovna):
            messagebox.showerror("chyba", "Ulice může obsahovat pouze písmena a mezery")
            raise ValueError('Ulice musí obsahovat pouze písmena a mezery')
        i_mesto_pojistovna = self.mesto_pojistovna_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_mesto_pojistovna):
            messagebox.showerror("chyba", "mesto může obsahovat pouze písmena a mezery")
            raise ValueError('mesto musí obsahovat pouze písmena a mezery')
        i_cislo_popisne_pojistovna = int(self.cislo_popisne_pojistovna_entry.get())
        i_psc_pojistovna = int(self.psc_pojistovna_entry.get())
        insert_statement = f"insert into pojistovna(nazev_pojistovna, ulice_pojistovna, mesto_pojistovna, cislo_popisne_pojistovna, psc_pojistovna) values(%s,%s,%s,%s,%s)"
        values = (i_nazev_pojistovna, i_ulice_pojistovna, i_mesto_pojistovna, i_cislo_popisne_pojistovna, i_psc_pojistovna)

        self.cursor.execute(insert_statement, values)
        self.connection.commit()
        messagebox.showinfo("Insert", "Přidali jste do tabulky Pojistovna")
        self.zavri_insert_pojistovna()


    def u_pojistovna(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro update Pojistovna ošetří je regurelníma výrazama a poté je
        vloží do update statementu pokud se update provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        a okno se zavře
        :return: nevraci nic
        """
        u_atribut = self.atribut_variable.get()
        u_uprava_atributu = self.uprava_atributu_entry.get()
        u_nazev_pojistovny = self.nazev_pojistovny_entry.get()

        if u_atribut == "nazev_pojistovna":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "Pojistovna může obsahovat pouze písmena a mezery")
                raise ValueError('Pojistovna musí obsahovat pouze písmena a mezery')
        elif u_atribut == "ulice_pojistovna":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "ulice může obsahovat pouze písmena a mezery")
                raise ValueError('ulice musí obsahovat pouze písmena a mezery')
        elif u_atribut == "mesto_pojistovna":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "mesto může obsahovat pouze písmena a mezery")
                raise ValueError('mesto musí obsahovat pouze písmena a mezery')

        update_statement = f"update pojistovna set {u_atribut} = '{u_uprava_atributu}' where nazev_pojistovna = '{u_nazev_pojistovny}'"
        self.cursor.execute(update_statement)
        self.connection.commit()
        messagebox.showinfo("Update", "Upravili jste tabulku Pojistovna")
        self.zavri_update_pojistovna()

    def d_pojistovna(self):
        """
        Tato tabulka vezme nazev Pojistovna z formuláře pro delete z tabulky Pojistovna zkontroluje ho a dosadí ho do
        delete statementu a delete provede
        :return: nevraci nic
        """
        d_nazev_pojistovny = self.nazev_pojistovny_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', d_nazev_pojistovny):
            messagebox.showerror("chyba", "pojistovna může obsahovat pouze písmena a mezery")
            raise ValueError('pojistovna musí obsahovat pouze písmena a mezery')

        delete_statement = f"delete from pojistovna where nazev_pojistovna = '{d_nazev_pojistovny}'"
        self.cursor.execute(delete_statement)
        self.connection.commit()
        messagebox.showinfo("Delete", "Vymazali jste z tabulky pojistovna")
        self.zavri_delete_pojistovna()
