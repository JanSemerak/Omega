import sys
import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
import ttkbootstrap
from Pacient import Pacient
from Pojistovna import Pojistovna
from Lekar import Lekar
from Nacini import Nacini
from Oddeleni import Oddeleni
from Navsteva import Navsteva
from Export import Export
from SmazatUcet import SmazatUcet
from Import import Import
from Report import Report
from Registrace import Registrace
from Nemocnice import Nemocnice
from Kafeterie import Kafeterie
from Report2 import Report2
from DatabaseConnection import DatabaseConnection


class LoginWindow(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

        self.master = master
        self.master.title("Přihlášení")

        self.heading_label = ttk.Label(self, text="Přihlášení", font=("Helvetica", 16, "bold"))
        self.heading_label.grid(row=0, column=0, columnspan=2, padx=100, pady=10, sticky="nsew")

        self.username_label = ttk.Label(self, text="Uživatelské jméno:")
        self.username_label.grid(row=1, column=0, padx=5, pady=5)

        self.username_entry = ttk.Entry(self)
        self.username_entry.grid(row=1, column=1, padx=5, pady=5)

        self.password_label = ttk.Label(self, text="Heslo:")
        self.password_label.grid(row=2, column=0, padx=5, pady=5)

        self.password_entry = ttk.Entry(self, show="*")
        self.password_entry.grid(row=2, column=1, padx=5, pady=5)

        self.register_button = ttkbootstrap.Button(self, text="registrovat se ", bootstyle="link",
                                                   command=self.registrace_button)
        self.register_button.grid(row=3, column=0, columnspan=2, padx=5, pady=5)

        self.login_button = ttk.Button(self, text="Přihlásit se", command=self.check_login)
        self.login_button.grid(row=5, column=0, columnspan=2, padx=5, pady=5)

        self.smazani_uzivatele_button =  ttkbootstrap.Button(self, text="Smazat ucet ", bootstyle="link",
                                                   command=self.smazani_uzivatele_button)
        self.smazani_uzivatele_button.grid(row=4, column=0, columnspan=2, padx=5, pady=5)

        self.pack()

    def registrace_button(self):
        """
        vytvoří objekt třídy Registrace a zavolá z ní metedu registrace_button
        :return:nevrací nic
        """
        registrace_window = Registrace(master=root)
        registrace_window.registrace_button()

    def zmena_hesla_button(self):
        """
        vytvoří objekt třídy Registrace a zavolá z ní metedu zapomenute_heslo
        :return:nevrací nic
        """
        zmena_hesla_window = Registrace(master=root)
        zmena_hesla_window.zapomenute_heslo()

    def smazani_uzivatele_button(self):
        """
        vytvoří objekt třídy Registrace a zavolá z ní metedu zapomenute_heslo
        :return:nevrací nic
        """
        smazani_uzivatele_window = SmazatUcet(master=root)
        smazani_uzivatele_window.smazat_button()

    def check_login(self):
        """
        Metoda vezme hodnoty z username a heslo, provede select jmena a hesla z tabulky prihlaseni, projede vypis for loopem
        pokud záznam neni v listu tak ho tam vloží a pokud je v listu tak ho přeskočí, poté projede list for loopem a
        porovná jestli je jmeno a heslo v listu pokud ano skryje prihlasovaci okno a zobrazí menu, pokud ne tak vyskoči
        nápis ze je spatně zadané jméno nebo heslo a dá uživateli možnost se registrovat nebo si změnit heslo
        :return: nevrací nic
        """
        username = self.username_entry.get()
        password = self.password_entry.get()
        prihlasovaci_udaje = []
        self.cursor.execute("select jmeno, heslo from prihlaseni;")
        vypis = self.cursor.fetchall()
        for row in vypis:
            if row in prihlasovaci_udaje:
                pass
            elif row not in prihlasovaci_udaje:
                prihlasovaci_udaje.append(row)
        for user in prihlasovaci_udaje:
            if user[0] == username and user[1] == password:
                self.master.withdraw()
                menuapp = MenuWindow(master=root)
                menuapp.mainloop()
            elif user[0] != username or user[1] != password:
                self.nespravne_prihlaseni_label = tk.Label(self, text="Zadali jste špatné jméno nebo heslo")
                self.nespravne_prihlaseni_label.configure(bg="red", fg="white")
                zmena_hesla_button = ttkbootstrap.Button(self, text="změnit heslo", bootstyle="link", command=self.zmena_hesla_button)
                zmena_hesla_button.grid(row=5, column=0, columnspan=2, padx=5, pady=5)
                self.register_button.grid(row=4, column=0, columnspan=2, padx=5, pady=5)
                self.login_button.grid(row=6, column=0, columnspan=2, padx=5, pady=5)
                self.nespravne_prihlaseni_label.grid(row=3,column=0, columnspan=2, padx=5, pady=5)

class MenuWindow(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

        menu = ThemedTk()
        menu.geometry("1920x1080")
        menu.title("Okenní menu s tlačítky")
        menu.configure(background="#282828")
        menu.configure(background="#282828")
        style = ttk.Style(menu)
        style.theme_use("equilux")

        def pacient_button():
            pacient_okno = Pacient(master=root)
            pacient_okno.pacient_button()

        def pojistovna_button():
            pojistovna_okno = Pojistovna(master=root)
            pojistovna_okno.pojistovna_button()

        def lekar_button():
            lekar_okno = Lekar(master=root)
            lekar_okno.lekar_button()

        def nacini_button():
            nacini_okno = Nacini(master=root)
            nacini_okno.nacini_button()

        def oddeleni_button():
            oddeleni_okno = Oddeleni(master=root)
            oddeleni_okno.oddeleni_button()

        def navsteva_button():
            navsteva_okno = Navsteva(master=root)
            navsteva_okno.navsteva_button()

        def nemocnice_button():
            nemocnice_okno = Nemocnice(master=root)
            nemocnice_okno.nemocnice_button()

        def kafeterie_button():
            kafeterie_okno = Kafeterie(master=root)
            kafeterie_okno.kafeterie_button()

        def export_button():
            export_dat_okno = Export(master=root)
            export_dat_okno.export_data()

        def import_button():
            import_dat_okno = Import(master=root)
            import_dat_okno.vyber_soubor()

        def souhrny_report_button():
            souhrny_report_okno = Report(master=root)
            souhrny_report_okno.souhrny_report()

        def souhrny_report_button2():
            souhrny_report_okno2 = Report2(master=root)
            souhrny_report_okno2.souhrny_report2()

        def odhlasi_se():
            self.master.deiconify()
            menu.destroy()

        def zavri_aplikaci():
            menu.destroy()
            sys.exit()

        main_frame = tk.Frame(menu)
        main_frame.pack(pady=200, padx=0)
        main_frame.configure(background="#282828")


        label = ttk.Label(main_frame, text="Aplikace pro nemocnice", font=("Helvetica", 40, "bold"),
                          background="#282828", foreground="white")
        label.pack(pady=(50, 10))

        frame1 = tk.Frame(main_frame)
        frame1.pack(pady=20)
        frame1.configure(background="#282828")

        buttons_row1 = [
            ("Tabulka Pacient", pacient_button),
            ("Tabulka Pojistovna", pojistovna_button),
            ("Tabulka Lekar", lekar_button),
            ("Tabulka Nacini", nacini_button),
            ("Tabulka Oddeleni", oddeleni_button),
            ("Tabulka Navsteva", navsteva_button),
        ]

        for i, (text, command) in enumerate(buttons_row1):
            button = ttk.Button(frame1, text=text, command=command, width=30)
            button.grid(row=0, column=i, padx=5, pady=10)

        frame2 = tk.Frame(main_frame)
        frame2.pack(pady=10)
        frame2.configure(background="#282828")

        buttons_row2 = [
            ("Tabulka Nemocnice", nemocnice_button),
            ("Tabulka Kafeterie", kafeterie_button),
            ("Export", export_button),
            ("Import dat", import_button),
            ("Souhrny report", souhrny_report_button),
            ("Souhrny report 2", souhrny_report_button2),
        ]

        for i, (text, command) in enumerate(buttons_row2):
            button = ttk.Button(frame2, text=text, command=command, width=30)
            button.grid(row=1, column=i, padx=5, pady=10)

        frame3 = tk.Frame(main_frame)
        frame3.pack(pady=10)
        frame3.configure(background="#282828")

        buttons_row3 = [
            ("Odhlásit se", odhlasi_se),
            ("Konec", zavri_aplikaci),
        ]

        for i, (text, command) in enumerate(buttons_row3):
            button = ttk.Button(frame3, text=text, command=command, width=30)
            button.grid(row=2, column=i, padx=5, pady=10)

        menu.mainloop()


root = tk.Tk()
app = LoginWindow(master=root)
app.mainloop()