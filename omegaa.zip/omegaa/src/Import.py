from tkinter import filedialog
from tkinter import messagebox
import csv
import json
import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
from DatabaseConnection import DatabaseConnection


class Import(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

    def vyber_soubor(self):
        """
        Tato metoda vytváří okno pro inmport dat do databáze
        :return: nevraci nic
        """
        self.import_values = ThemedTk()
        self.import_values.title("Import dat")
        self.import_values.geometry("500x350")
        self.import_values.configure(background="#282828")
        style = ttk.Style(self.import_values)
        style.theme_use("equilux")

        label = ttk.Label(self.import_values, text="Import dat ")
        label.configure(background="#282828", padding=40, font=("Helvetica", 20, "bold"), foreground="white")
        label.pack()

        self.atribut = ["lekar", "nacini", "navsteva", "oddeleni", "pacient", "pojistovna","nemocnice", "kafeterie"]
        self.atribut_variable = tk.StringVar(self.import_values)
        self.atribut_variable.set(self.atribut[0])
        self.dropdown = ttk.OptionMenu(self.import_values, self.atribut_variable, *self.atribut)
        self.dropdown.configure(padding=15)
        self.dropdown.pack(pady=12)

        button = ttk.Button(self.import_values, text="vyber soubor", command=self.import_into_table)
        button.pack(pady=12)
        zpet_button = ttk.Button(self.import_values, text="zpet", command=self.zpet_do_menu)
        zpet_button.pack()
        self.import_values.mainloop()

    csv_dict = {"lekar": "insert into lekar(jmeno_lekar, prijmeni_lekar, identifikacni_cislo_lekar, telefonni_cislo_lekar, id_oddeleni,id_nemocnice) values(%s,%s,%s,%s,%s,%s)",
                "nacini": "insert into nacini(nazev_nacini, kategorii_nacini, vyrobce) values(%s,%s,%s)",
                "navsteva": "insert into navsteva(datum_navsteva, cena_navsteva, id_pacient, id_lekar, id_nacini) values(%s,%s,%s,%s,%s)",
                "oddeleni": "insert into oddeleni(nazev_oddeleni, telefonni_cislo_oddeleni, patro_oddeleni) values(%s,%s,%s)",
                "pacient": "insert into pacient(jmeno_pacient, prijmeni_pacient, rodne_cislo_pacient, telefonni_cislo_pacient, ulice_pacient, mesto_pacient, cislo_popisne_pacient, psc_pacient, id_pojistovna) values(%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                "pojistovna": "insert into pojistovna(nazev_pojistovna, ulice_pojistovna, mesto_pojistovna, cislo_popisne_pojistovna, psc_pojistovna) values(%s,%s,%s,%s,%s)",
                "nemocnice": "insert into nemocnice(nazev_nemocnice, ulice_nemocnice, mesto_nemocnice, cislo_popisne_nemocnice, psc_nemocnice,id_kafeterie) values(%s,%s,%s,%s,%s,%s)",
                "kafeterie": "insert into kafeterie(nazev_jidla, cena, rozmer, pocet_zamestnancu) values(%s, %s, %s, %s)"
                }

    json_dict = {"lekar": "insert into lekar(jmeno_lekar, prijmeni_lekar, identifikacni_cislo_lekar, telefonni_cislo_lekar, id_oddeleni) values('{0}','{1}','{2}','{3}','{4}');",
                 "nacini": "insert into nacini(nazev_nacini, kategorii_nacini, vyrobce) values('{0}','{1}','{2}');",
                 "navsteva": "insert into navsteva(datum_navsteva, cena_navsteva, id_pacient, id_lekar, id_nacini) values('{0}','{1}','{2}','{3}','{4}');",
                 "oddeleni": "insert into oddeleni(nazev_oddeleni, telefonni_cislo_oddeleni, patro_oddeleni) values('{0}','{1}','{2}');",
                 "pacient": "insert into pacient(jmeno_pacient, prijmeni_pacient, rodne_cislo_pacient, telefonni_cislo_pacient, ulice_pacient, mesto_pacient, cislo_popisne_pacient, psc_pacient, id_pojistovna) values('{0}','{1}',{2},'{3}','{4}','{5}','{6}','{7}','{8}');",
                 "pojistovna": "insert into pojistovna(nazev_pojistovna, ulice_pojistovna, mesto_pojistovna, cislo_popisne_pojistovna, psc_pojistovna) values('{0}','{1}','{2}','{3}','{4}');",
                 "nemocnice": "insert into nemocnice(nazev_nemocnice, ulice_nemocnice, mesto_nemocnice, cislo_popisne_nemocnice, psc_nemocnice,id_kafeterie) values('{0}','{1}','{2}','{3}','{4}','{5}');",
                 "kafeterie": "insert into kafeterie(nazev_jidla, cena, rozmer, pocet_zamestnancu) values('{0}','{1}','{2}','{3}');"
                 }


    def get_csv_dict(self,vybrana_tabulka):
        """
        metoda vrací z dictionary csv insert statement
        :param vybrana_tabulka: nazev tabulky pro kterou vrátit insert statement
        :return: insert statement
        """
        return self.csv_dict[vybrana_tabulka]

    def get_json_dict(self,vybrana_tabulka):
        """
        metoda vrací z dictionary json insert statement
        :param vybrana_tabulka: nazev tabulky pro kterou vrátit insert statement
        :return: insert statement
        """
        return self.json_dict[vybrana_tabulka]

    def import_into_table(self):
        """
        Metoda vezme vybranou tabulku z robalovacího meny poté otevře okno pro výběr souboru poté pomocí .split zjistí
        konovku souboru pokud je koncovka csv zavolá metodu get_csv_dict která podle vybrného názvu tabulky vrátí insert
        statement poté otevře soubor pro čtení přečte ho pomocí csv readeru přeskočí hlavičku poté for loopem projede
        csv reader a data dosadí do insert statmentu a odešle do db. Pokud je koncovka json zavolá metodu get_json_dict
        která podle vybrného názvu tabulky vrátí insert statement, poté otevře soubor pro čtení načte data projede
        data for loopem po řádku a data vloží do insert statementu a insert statement se vloží listu poté se list projede for
        loopem po insertu a každý commmand se commitne do db. pokud nastane chyba při importu vyskočí okenko s chybovou hláškou
        :return:nevrací nic
        """
        vybrana_tabulka = self.atribut_variable.get()
        filename = filedialog.askopenfilename(initialdir="/", title="Select a File", filetypes=(("Text files", "*.txt*"), ("all files", "*.*")))
        soubor = filename
        koncovka = filename.split(".")
        if koncovka[1] == "csv":
            try:
                insert_statement_csv = self.get_csv_dict(vybrana_tabulka)

                with open(soubor, 'r') as file:
                    reader = csv.reader(file)
                    header = next(reader)
                    for row in reader:
                        print(row)
                        self.cursor.execute(insert_statement_csv, row)
                messagebox.showinfo("Import", " Úspěšně jste importovali data")
            except:
                messagebox.showerror("chyba", "insert se nepovedl!!!!!!\n\rzkuste zkontrolovat soubor zda neobsahuje duplicitní hodnoty")
                self.pripojeni.rollback()
        elif koncovka[1] == "json":
            try:
                insert_commands = []

                insert_command_json = self.get_json_dict(vybrana_tabulka)

                if vybrana_tabulka == "lekar":
                    with open(soubor) as f:
                        data = json.load(f)
                    for row in data:
                        insert_commands.append(insert_command_json.format(row['jmeno_lekar'], row['prijmeni_lekar'], row['identifikacni_cislo_lekar'], row['telefonni_cislo_lekar'], row['id_oddeleni']))
                elif vybrana_tabulka == "nacini":
                    with open(soubor) as f:
                        data = json.load(f)
                    for row in data:
                        insert_commands.append(insert_command_json.format(row['nazev_nacini'], row['kategorii_nacini'], row['vyrobce']))
                elif vybrana_tabulka == "navsteva":
                    with open(soubor) as f:
                        data = json.load(f)
                    for row in data:
                        insert_commands.append(insert_command_json.format(row['datum_navsteva'], row['cena_navsteva'], row['id_pacient'],row['id_lekar'], row['id_nacini'], row['ulice'], row['cislo_popisne']))
                elif vybrana_tabulka == "oddeleni":
                    with open(soubor) as f:
                        data = json.load(f)
                    for row in data:
                        insert_commands.append(insert_command_json.format(row['nazev_oddeleni'], row['telefonni_cislo_oddeleni'], row['patro_oddeleni']))
                elif vybrana_tabulka == "pacient":
                    with open(soubor) as f:
                        data = json.load(f)
                    for row in data:
                        insert_commands.append(insert_command_json.format(row['jmeno_pacient'], row['prijmeni_pacient'], row['rodne_cislo_pacient'],row['telefonni_cislo_pacient'], row['ulice_pacient'], row['mesto_pacient'], row['cislo_popisne_pacient'], row['psc_pacient'], row['id_pojistovna']))
                elif vybrana_tabulka == "pojistovna":
                    with open(soubor) as f:
                        data = json.load(f)
                    for row in data:
                        insert_commands.append(insert_command_json.format(row['nazev_pojistovna'], row['ulice_pojistovna'], row['mesto_pojistovna'],row['cislo_popisne_pojistovna'], row['psc_pojistovna']))
                elif vybrana_tabulka == "nemocnice":
                    with open(soubor) as f:
                        data = json.load(f)
                    for row in data:
                        insert_commands.append(insert_command_json.format(row['nazev_nemocnice'], row['ulice_nemocnice'], row['mesto_nemocnice'],row['cislo_popisne_nemocnice'], row['psc_nemocnice'], row['id_kafeterie']))
                elif vybrana_tabulka == "kafeterie":
                    with open(soubor) as f:
                        data = json.load(f)
                    for row in data:
                        insert_commands.append(insert_command_json.format(row['nazev_jidla'], row['cena'], row['rozmer'],row['pocet_zamestnancu']))
                for command in insert_commands:
                    self.cursor.execute(command)
                messagebox.showinfo("Import", " Úspěšně jste importovali data")
            except:
                messagebox.showerror("chyba", "insert se nepovedl!!!!!!!!!\n\rzkuste zkontrolovat soubor zda neobsahuje duplicitní hodnoty")
                self.connection.rollback()
        self.connection.commit()

    def zpet_do_menu(self):
        """
        zavře okno pro import dat
        :return: nevraci nic
        """
        self.import_values.destroy()
