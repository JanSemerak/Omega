import tkinter as tk
from tkinter import ttk

import mysql.connector
from ttkthemes import ThemedTk
from tkinter import messagebox
import re
from DatabaseConnection import DatabaseConnection


class Lekar(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

    def lekar_button(self):
        """
        Tato metoda vytváří okno které obsahuje tabulku Lekar a tlačítka pro insert, update a delete tlačítko
        které okno zavře a do menu
        :return: nevrací nic
        """
        self.cursor.execute("SELECT lekar.id_lekar, lekar.jmeno_lekar, lekar.prijmeni_lekar, lekar.identifikacni_cislo_lekar, lekar.telefonni_cislo_lekar, lekar.id_oddeleni, lekar.id_nemocnice FROM lekar")
        rows = self.cursor.fetchall()

        lekar = ThemedTk()
        lekar.title("lekar")
        lekar.geometry("1920x1080")
        lekar.configure(background="#282828")
        style = ttk.Style(lekar)
        style.theme_use("equilux")

        self.lekar_main_frame = tk.Frame(lekar)
        self.lekar_main_frame.grid(row=1, column=0, padx=25, pady=200)
        self.lekar_main_frame.configure(background="#282828")

        self.lekar = ttk.Label(self.lekar_main_frame, text="Tabulka lekar")
        self.lekar.grid(row=0)
        self.lekar.configure(background="#282828", padding=22, font=("Helvetica", 40, "bold"), foreground="white")

        self.table_frame = tk.Frame(self.lekar_main_frame)
        self.table_frame.grid(row=1, column=0, padx=10, pady=5)
        self.table_frame.configure(background="#282828")

        table = ttk.Treeview(self.table_frame, columns=(
           "jmeno_lekar", "prijmeni_lekar", "identifikacni_cislo_lekar", "telefonni_cislo_lekar", "id_oddeleni", "id_nemocnice"))

        table.heading("#0", text="ID")
        table.heading("jmeno_lekar", text="jmeno_lekar")
        table.heading("prijmeni_lekar", text="prijmeni_lekar")
        table.heading("identifikacni_cislo_lekar", text="identifikacni_cislo_lekar")
        table.heading("telefonni_cislo_lekar", text="telefonni_cislo_lekar")
        table.heading("id_oddeleni", text="id_oddeleni")
        table.heading("id_nemocnice", text="id_nemocnice")

        for row in rows:
            table.insert("", "end", text=row[0], values=(row[1], row[2], row[3], row[4], row[5], row[6]))

        table.grid(row=1, pady=5, padx=210)

        def zavri_lekare():
            lekar.destroy()

        self.button_frame = tk.Frame(self.lekar_main_frame)
        self.button_frame.grid(row=2, column=0, padx=0, pady=5)
        self.button_frame.configure(background="#282828")

        self.zpet_button_frame = tk.Frame(self.lekar_main_frame)
        self.zpet_button_frame.grid(row=3, column=0, padx=0, pady=5)
        self.zpet_button_frame.configure(background="#282828")

        insert_lekar = ttk.Button(self.button_frame, text="insert", command=self.insert_lekar_window)
        update_lekar = ttk.Button(self.button_frame, text="update", command=self.update_lekar_window)
        delete_lekar = ttk.Button(self.button_frame, text="delete", command=self.delete_lekar_window)
        zpet = ttk.Button(self.zpet_button_frame, text="zpet", command=zavri_lekare)
        insert_lekar.grid(padx=5,pady=5, row=2, column=0)
        update_lekar.grid(padx=5,pady=5, row=2, column=1)
        delete_lekar.grid(padx=5,pady=5, row=2, column=2)
        zpet.grid(pady=5, row=5, column=0)

    def insert_lekar_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vložení záznamu do tabulky lekar
        :return:nevrací nic
        """
        self.insert_lekar = ThemedTk()
        self.insert_lekar.title("insert lekar")
        self.insert_lekar.geometry("400x390")
        self.insert_lekar.configure(background="#282828")
        style = ttk.Style(self.insert_lekar)
        style.theme_use("equilux")

        self.lek = ttk.Label(self.insert_lekar, text="Insert lekar")
        self.lek.grid(row=0)
        self.lek.configure(background="#282828", padding=20, font=("Helvetica", 20, "bold"), foreground="white")

        self.insert_lekar_main_frame = tk.Frame(self.insert_lekar)
        self.insert_lekar_main_frame.grid(row=1, column=0, padx=0, pady=5)
        self.insert_lekar_main_frame.configure(background="#282828")

        self.jmeno_lekar_frame = tk.Frame(self.insert_lekar_main_frame)
        self.jmeno_lekar_frame.grid(row=0, column=0, pady=5, padx=5, sticky= "ew")
        self.jmeno_lekar_frame.configure(background="#282828")

        self.jmeno_lekar_label = ttk.Label(self.jmeno_lekar_frame, text="jmeno lekare:")
        self.jmeno_lekar_label.grid(row=0, column=0, padx=5, pady=5,sticky ="w")
        self.jmeno_lekar_label.configure(background="#282828", foreground="lightgray")

        self.jmeno_lekar_entry = ttk.Entry(self.jmeno_lekar_frame)
        self.jmeno_lekar_entry.grid(row=0, column=1, padx=5, pady=5)

        self.prijmeni_lekar_frame = tk.Frame(self.insert_lekar_main_frame)
        self.prijmeni_lekar_frame.grid(row=1, column=0, pady=5, padx=5, sticky= "ew")
        self.prijmeni_lekar_frame.configure(background="#282828")

        self.prijmeni_lekar_label = ttk.Label(self.prijmeni_lekar_frame, text="prijmeni lekare:")
        self.prijmeni_lekar_label.grid(row=1, column=0, padx=5, pady=5,sticky ="w")
        self.prijmeni_lekar_label.configure(background="#282828", foreground="lightgray")

        self.prijmeni_lekar_entry = ttk.Entry(self.prijmeni_lekar_frame)
        self.prijmeni_lekar_entry.grid(row=1, column=1, padx=5, pady=5)

        self.identifikacni_cislo_lekar_frame = tk.Frame(self.insert_lekar_main_frame)
        self.identifikacni_cislo_lekar_frame.grid(row=2, column=0, pady=5, padx=5, sticky= "ew")
        self.identifikacni_cislo_lekar_frame.configure(background="#282828")

        self.identifikacni_cislo_lekar_label = ttk.Label(self.identifikacni_cislo_lekar_frame, text="identifikacni cislo lekare:")
        self.identifikacni_cislo_lekar_label.grid(row=2, column=0, padx=5, pady=5,sticky ="w")
        self.identifikacni_cislo_lekar_label.configure(background="#282828", foreground="lightgray")

        self.identifikacni_cislo_lekar_entry = ttk.Entry(self.identifikacni_cislo_lekar_frame)
        self.identifikacni_cislo_lekar_entry.grid(row=2, column=1, padx=5, pady=5)

        self.telefonni_cislo_lekar_frame = tk.Frame(self.insert_lekar_main_frame)
        self.telefonni_cislo_lekar_frame.grid(row=3, column=0, pady=5, padx=5, sticky= "ew")
        self.telefonni_cislo_lekar_frame.configure(background="#282828")

        self.telefonni_cislo_lekar_label = ttk.Label(self.telefonni_cislo_lekar_frame, text="telefonni cislo lekare:")
        self.telefonni_cislo_lekar_label.grid(row=3, column=0, padx=5, pady=5,sticky ="w")
        self.telefonni_cislo_lekar_label.configure(background="#282828", foreground="lightgray")

        self.telefonni_cislo_lekar_entry = ttk.Entry(self.telefonni_cislo_lekar_frame)
        self.telefonni_cislo_lekar_entry.grid(row=3, column=1, padx=5, pady=5)

        self.id_oddeleni_frame = tk.Frame(self.insert_lekar_main_frame)
        self.id_oddeleni_frame.grid(row=4, column=0, pady=5, padx=5, sticky= "ew")
        self.id_oddeleni_frame.configure(background="#282828")

        self.id_oddeleni_label = ttk.Label(self.id_oddeleni_frame, text="id oddeleni:")
        self.id_oddeleni_label.grid(row=4, column=0, padx=5, pady=5,sticky ="w")
        self.id_oddeleni_label.configure(background="#282828", foreground="lightgray")

        self.id_oddeleni_entry = ttk.Entry(self.id_oddeleni_frame)
        self.id_oddeleni_entry.grid(row=4, column=1, padx=5, pady=5)

        self.id_nemocnice_frame = tk.Frame(self.insert_lekar_main_frame)
        self.id_nemocnice_frame.grid(row=5, column=0, pady=5, padx=5, sticky= "ew")
        self.id_nemocnice_frame.configure(background="#282828")

        self.id_nemocnice_label = ttk.Label(self.id_nemocnice_frame, text="id nemocnice:")
        self.id_nemocnice_label.grid(row=5, column=0, padx=5, pady=5,sticky ="w")
        self.id_nemocnice_label.configure(background="#282828", foreground="lightgray")

        self.id_nemocnice_entry = ttk.Entry(self.id_nemocnice_frame)
        self.id_nemocnice_entry.grid(row=5, column=1, padx=5, pady=5)

        self.odeslat_button = ttk.Button(self.insert_lekar, text="Odeslat", command=self.i_lekar)
        self.odeslat_button.grid(row=6, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.insert_lekar, text="Help", command=self.i_informace_lekar)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def update_lekar_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro upravení záznamu v tabulce lekar
        :return:nevrací nic
        """
        self.update_lekar = ThemedTk()
        self.update_lekar.title("update lekar")
        self.update_lekar.geometry("340x220")
        self.update_lekar.configure(background="#282828")
        style = ttk.Style(self.update_lekar)
        style.theme_use("equilux")

        self.atribut = ttk.Label(self.update_lekar, text="atribut který chcete upravit v tabulce lekar:")
        self.atribut.grid(row=0, column=0, padx=1, pady=2)
        self.atribut.configure(background="#282828", foreground="lightgray")

        self.atribut = ["jmeno_lekar", "prijmeni_lekar", "identifikacni_cislo_lekar", "telefonni_cislo_lekar", "id_oddeleni","id_nemocnice"]
        self.atribut_variable = tk.StringVar(self.update_lekar)
        self.atribut_variable.set(self.atribut[0])
        self.dropdown = ttk.OptionMenu(self.update_lekar, self.atribut_variable, *self.atribut)
        self.dropdown.grid(row=1, column=0, padx=1, pady=2)

        self.uprava_atributu = ttk.Label(self.update_lekar, text="na co chcete daný atribut opravit:")
        self.uprava_atributu.grid(row=2, column=0, padx=1, pady=2)
        self.uprava_atributu.configure(background="#282828", foreground="lightgray")

        self.uprava_atributu_entry = ttk.Entry(self.update_lekar)
        self.uprava_atributu_entry.grid(row=3, column=0, padx=1, pady=2)

        self.jmeno_lekare = ttk.Label(self.update_lekar,text="jmeno lekare u kterého chcete atribut upravit:")
        self.jmeno_lekare.grid(row=4, column=0, padx=1, pady=2)
        self.jmeno_lekare.configure(background="#282828", foreground="lightgray")

        self.jmeno_lekare_entry = ttk.Entry(self.update_lekar)
        self.jmeno_lekare_entry.grid(row=5, column=0, padx=1, pady=2)

        self.login_button = ttk.Button(self.update_lekar, text="Odeslat", command=self.u_lekar)
        self.login_button.grid(row=6, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.insert_lekar, text="Help", command=self.u_informace_lekar)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def delete_lekar_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vymazání záznamu z tabulky lekar
        :return:nevrací nic
        """
        self.delete_lekar = ThemedTk()
        self.delete_lekar.title("delete lekar")
        self.delete_lekar.configure(background="#282828")
        style = ttk.Style(self.delete_lekar)
        style.theme_use("equilux")

        self.jmeno_lekare = ttk.Label(self.delete_lekar, text="zadejte jmeno lekare kterou chcete smazat:")
        self.jmeno_lekare.grid(row=0, column=0, padx=1, pady=2)
        self.jmeno_lekare.configure(background="#282828", foreground="lightgray")

        self.jmeno_lekare_entry = ttk.Entry(self.delete_lekar)
        self.jmeno_lekare_entry.grid(row=1, column=0, padx=1, pady=2)

        self.odeslat_button = ttk.Button(self.delete_lekar, text="Odeslat", command=self.d_lekar)
        self.odeslat_button.grid(row=2, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.insert_lekar, text="Help", command=self.d_informace_lekar)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def zavri_insert_lekar(self):
        """
        tato metoda zavře okno pro insert lekar
        :return:nevrací nic
        """
        self.insert_lekar.destroy()

    def zavri_update_lekar(self):
        """
        tato metoda zavře okno pro update lekar
        :return:nevrací nic
        """
        self.update_lekar.destroy()

    def zavri_delete_lekar(self):
        """
        tato metoda zavře okno pro delete lekar
        :return:nevrací nic
        """
        self.delete_lekar.destroy()

    def i_informace_lekar(self):
        messagebox.showinfo("Info","Pro úspěšný insert vyplňte správně všechny kolonky")

    def u_informace_lekar(self):
        messagebox.showinfo("Info","Pro úspěšný update zvolte řádek, který chcete změnit a poté vyplňte správně kolonky")

    def d_informace_lekar(self):
        messagebox.showinfo("Info","Pro úspěšný delete vyplňte správně název")

    def i_lekar(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro insert lekare ošetří je regurelníma výrazama a poté je
        vloží do insert statementu pokud se insert provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        pokud uživatel zadá určitý atribut který musí být pro každý záznam unikátní tak na neho vyskočí okénko že musí
        být daný atribut unikátní
        :return: nevrací nic
        """
        i_jmeno_lekar = self.jmeno_lekar_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_jmeno_lekar):
            messagebox.showerror("chyba", "Jméno lékaře může obsahovat pouze písmena a mezery")
            raise ValueError('Jméno lékaře musí obsahovat pouze písmena a mezery')
        i_prijmeni_lekar = self.prijmeni_lekar_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_prijmeni_lekar):
            messagebox.showerror("chyba", "Příjmení lékaře může obsahovat pouze písmena a mezery")
            raise ValueError('Příjmení lékaře musí obsahovat pouze písmena a mezery')
        i_identifikacni_cislo_lekar = self.identifikacni_cislo_lekar_entry.get()
        if not re.match(r'^[a-zA-Z0-9]{5}$', i_identifikacni_cislo_lekar):
            messagebox.showerror("chyba", "Identifikační číslo musí obsahovat přesně 5 znaků")
            raise ValueError('Identifikační číslo musí obsahovat právě 5 znaků')
        i_telefonni_cislo_lekar = self.telefonni_cislo_lekar_entry.get()
        if not re.match(r'^\d{9}$', i_telefonni_cislo_lekar):
            messagebox.showerror("chyba", "Telefon musí obsahovat přesně 9 číslic")
            raise ValueError('Telefon musí obsahovat právě 9 číslic')
        i_id_oddeleni = int(self.id_oddeleni_entry.get())
        i_id_nemocnice = int(self.id_nemocnice_entry.get())

        try:
            insert_statement = f"insert into lekar(jmeno_lekar, prijmeni_lekar, identifikacni_cislo_lekar, telefonni_cislo_lekar, id_oddeleni,id_nemocnice) values(%s,%s,%s,%s,%s,%s)"
            values = (i_jmeno_lekar, i_prijmeni_lekar, i_identifikacni_cislo_lekar, i_telefonni_cislo_lekar, i_id_oddeleni,i_id_nemocnice)

            self.cursor.execute(insert_statement, values)
            self.connection.commit()
            messagebox.showinfo("Insert", "Přidali jste do tabulky lekar")
            self.zavri_insert_lekar()
        except mysql.connector.errors.IntegrityError:
            messagebox.showerror("Chyba", "Telefonni cislo a Identifikacni cislo musi byt unikatni ")

    def u_lekar(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro update lekare ošetří je regurelníma výrazama a poté je
        vloží do update statementu pokud se update provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        a okno se zavře
        :return: nevraci nic
        """
        u_atribut = self.atribut_variable.get()
        u_uprava_atributu = self.uprava_atributu_entry.get()
        u_jmeno_lekare = self.jmeno_lekare_entry.get()

        if u_atribut == "jmeno_lekar":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "Jméno lékaře může obsahovat pouze písmena a mezery")
                raise ValueError('Jméno lékaře musí obsahovat pouze písmena a mezery')
        elif u_atribut == "prijmeni_lekar":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "Příjmení lékaře může obsahovat pouze písmena a mezery")
                raise ValueError('Příjmení lékaře musí obsahovat pouze písmena a mezery')
        elif u_atribut == "identifikacni_cislo_lekar":
            if not re.match(r'^[a-zA-Z0-9]{5}$', u_uprava_atributu):
                messagebox.showerror("chyba", "Identifikační číslo musí obsahovat přesně 5 znaků")
                raise ValueError('Identifikační číslo musí obsahovat právě 5 znaků')
        elif u_atribut == "telefonni_cislo_lekar":
            if not re.match(r'^\d{9}$', u_uprava_atributu):
                messagebox.showerror("chyba", "Telefon musí obsahovat přesně 9 číslic")
                raise ValueError('Telefon musí obsahovat právě 9 číslic')

        update_statement = f"update lekar set {u_atribut} = '{u_uprava_atributu}' where jmeno_lekar = '{u_jmeno_lekare}'"
        self.cursor.execute(update_statement)
        self.connection.commit()
        messagebox.showinfo("Update", "Upravili jste tabulku lekar")
        self.zavri_update_lekar()

    def d_lekar(self):
        """
        Tato tabulka vezme jméno lekare z formuláře pro delete z tabulky lekar zkontroluje ho a dosadí ho do
        delete statementu a delete provede
        :return: nevraci nic
        """
        d_jmeno_lekare = self.jmeno_lekare_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', d_jmeno_lekare):
            messagebox.showerror("chyba", "Jméno lékaře může obsahovat pouze písmena a mezery")
            raise ValueError('Jméno lékaře musí obsahovat pouze písmena a mezery')

        delete_statement = f"delete from lekar where jmeno_lekar = '{d_jmeno_lekare}'"
        self.cursor.execute(delete_statement)
        self.connection.commit()
        messagebox.showinfo("Delete", "Vymazali jste z tabulky lekar")
        self.zavri_delete_lekar()
