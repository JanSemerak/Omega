import re
import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
from tkinter import messagebox
from DatabaseConnection import DatabaseConnection


class Nacini(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

    def nacini_button(self):
        """
        Tato metoda vytváří okno které obsahuje tabulku nacini a tlačítka pro insert, update a delete tlačítko
        které okno zavře a do menu
        :return: nevrací nic
        """
        self.cursor.execute("SELECT nacini.id_nacini, nacini.nazev_nacini, nacini.kategorii_nacini, nacini.vyrobce FROM nacini")
        rows = self.cursor.fetchall()

        nacini = ThemedTk()
        nacini.title("nacini")
        nacini.geometry("1920x1080")
        nacini.configure(background="#282828")
        nacini.configure(background="#282828")
        style = ttk.Style(nacini)
        style.theme_use("equilux")

        self.nacini_main_frame = tk.Frame(nacini)
        self.nacini_main_frame.grid(row=1, column=0, padx=300, pady=200)
        self.nacini_main_frame.configure(background="#282828")

        self.nacini = ttk.Label(self.nacini_main_frame, text="Tabulka nacini")
        self.nacini.grid(row=0)
        self.nacini.configure(background="#282828", padding=20, font=("Helvetica", 40, "bold"), foreground="white")

        self.table_frame = tk.Frame(self.nacini_main_frame)
        self.table_frame.grid(row=1, column=0, padx=10, pady=5)
        self.table_frame.configure(background="#282828")

        table = ttk.Treeview(self.table_frame, columns=(
           "nazev_nacini", "kategorii_nacini", "vyrobce"))

        table.heading("#0", text="ID")
        table.heading("nazev_nacini", text="nazev_nacini")
        table.heading("kategorii_nacini", text="kategorii_nacini")
        table.heading("vyrobce", text="vyrobce")

        for row in rows:
            table.insert("", "end", text=row[0], values=(row[1], row[2], row[3]))

        table.grid(row=1, pady=5, padx=210)

        def zavri_nacini():
            nacini.destroy()

        self.button_frame = tk.Frame(self.nacini_main_frame)
        self.button_frame.grid(row=2, column=0, padx=0, pady=5)
        self.button_frame.configure(background="#282828")

        self.zpet_button_frame = tk.Frame(self.nacini_main_frame)
        self.zpet_button_frame.grid(row=3, column=0, padx=0, pady=5)
        self.zpet_button_frame.configure(background="#282828")

        insert_nacini = ttk.Button(self.button_frame, text="insert", command=self.insert_nacini_window)
        update_nacini = ttk.Button(self.button_frame, text="update", command=self.update_nacini_window)
        delete_nacini = ttk.Button(self.button_frame, text="delete", command=self.delete_nacini_window)
        zpet = ttk.Button(self.zpet_button_frame, text="zpet", command=zavri_nacini)
        insert_nacini.grid(padx=5,pady=5, row=2, column=0)
        update_nacini.grid(padx=5,pady=5, row=2, column=1)
        delete_nacini.grid(padx=5,pady=5, row=2, column=2)
        zpet.grid(pady=5, row=5, column=0)

    def insert_nacini_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vložení záznamu do tabulky nacini
        :return:nevrací nic
        """
        self.insert_nacini = ThemedTk()
        self.insert_nacini.title("insert nacini")
        self.insert_nacini.geometry("340x280")
        self.insert_nacini.configure(background="#282828")
        style = ttk.Style(self.insert_nacini)
        style.theme_use("equilux")

        self.nac = ttk.Label(self.insert_nacini, text="Insert nacini")
        self.nac.grid(row=0)
        self.nac.configure(background="#282828", padding=20, font=("Helvetica", 20, "bold"), foreground="white")

        self.insert_nacini_main_frame = tk.Frame(self.insert_nacini)
        self.insert_nacini_main_frame.grid(row=1, column=0, padx=0, pady=5)
        self.insert_nacini_main_frame.configure(background="#282828")

        self.nazev_nacini_frame = tk.Frame(self.insert_nacini_main_frame)
        self.nazev_nacini_frame.grid(row=0, column=0, pady=5, padx=5, sticky= "ew")
        self.nazev_nacini_frame.configure(background="#282828")

        self.nazev_nacini_label = ttk.Label(self.nazev_nacini_frame, text="nacini:")
        self.nazev_nacini_label.grid(row=0, column=0, padx=5, pady=5,sticky ="w")
        self.nazev_nacini_label.configure(background="#282828", foreground="lightgray")

        self.nazev_nacini_entry = ttk.Entry(self.nazev_nacini_frame)
        self.nazev_nacini_entry.grid(row=0, column=1, padx=5, pady=5)

        self.kategorii_nacini_frame = tk.Frame(self.insert_nacini_main_frame)
        self.kategorii_nacini_frame.grid(row=1, column=0, pady=5, padx=5, sticky= "ew")
        self.kategorii_nacini_frame.configure(background="#282828")

        self.kategorii_nacini_label = ttk.Label(self.kategorii_nacini_frame, text="kategorie:")
        self.kategorii_nacini_label.grid(row=1, column=0, padx=5, pady=5,sticky ="w")
        self.kategorii_nacini_label.configure(background="#282828", foreground="lightgray")

        self.kategorii_nacini_entry = ttk.Entry(self.kategorii_nacini_frame)
        self.kategorii_nacini_entry.grid(row=1, column=1, padx=5, pady=5)

        self.vyrobce_frame = tk.Frame(self.insert_nacini_main_frame)
        self.vyrobce_frame.grid(row=2, column=0, pady=5, padx=5, sticky= "ew")
        self.vyrobce_frame.configure(background="#282828")

        self.vyrobce_label = ttk.Label(self.kategorii_nacini_frame, text="vyrobce:")
        self.vyrobce_label.grid(row=2, column=0, padx=5, pady=5,sticky ="w")
        self.vyrobce_label.configure(background="#282828", foreground="lightgray")

        self.vyrobce_entry = ttk.Entry(self.kategorii_nacini_frame)
        self.vyrobce_entry.grid(row=2, column=1, padx=5, pady=5)

        self.odeslat_button = ttk.Button(self.insert_nacini, text="Odeslat", command=self.i_nacini)
        self.odeslat_button.grid(row=3, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.insert_nacini, text="Help", command=self.i_informace_nacini)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def update_nacini_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro upravení záznamu v tabulce nacini
        :return:nevrací nic
        """
        self.update_nacini = ThemedTk()
        self.update_nacini.title("update nacini")
        self.update_nacini.geometry("340x240")
        self.update_nacini.configure(background="#282828")
        style = ttk.Style(self.update_nacini)
        style.theme_use("equilux")

        self.atribut = ttk.Label(self.update_nacini, text="atribut který chcete upravit v tabulce nacini:")
        self.atribut.grid(row=0, column=0, padx=1, pady=2)
        self.atribut.configure(background="#282828", foreground="lightgray")

        self.atribut = ["nazev_nacini", "kategorii_nacini", "vyrobce"]
        self.atribut_variable = tk.StringVar(self.update_nacini)
        self.atribut_variable.set(self.atribut[0])
        self.dropdown = ttk.OptionMenu(self.update_nacini, self.atribut_variable, *self.atribut)
        self.dropdown.grid(row=1, column=0, padx=1, pady=2)

        self.uprava_atributu = ttk.Label(self.update_nacini, text="na co chcete daný atribut opravit:")
        self.uprava_atributu.grid(row=2, column=0, padx=1, pady=2)
        self.uprava_atributu.configure(background="#282828", foreground="lightgray")

        self.uprava_atributu_entry = ttk.Entry(self.update_nacini)
        self.uprava_atributu_entry.grid(row=3, column=0, padx=1, pady=2)

        self.nazev_nacini = ttk.Label(self.update_nacini,text="nacini u kterého chcete atribut upravit:")
        self.nazev_nacini.grid(row=4, column=0, padx=1, pady=2)
        self.nazev_nacini.configure(background="#282828", foreground="lightgray")

        self.nazev_nacini_entry = ttk.Entry(self.update_nacini)
        self.nazev_nacini_entry.grid(row=5, column=0, padx=1, pady=2)

        self.login_button = ttk.Button(self.update_nacini, text="Odeslat", command=self.u_nacini)
        self.login_button.grid(row=6, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.update_nacini, text="Help", command=self.u_informace_nacini)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)
    def delete_nacini_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vymazání záznamu z tabulky nacini
        :return:nevrací nic
        """
        self.delete_nacini = ThemedTk()
        self.delete_nacini.title("delete nacini")
        self.delete_nacini.configure(background="#282828")
        style = ttk.Style(self.delete_nacini)
        style.theme_use("equilux")

        self.nazev_nacini = ttk.Label(self.delete_nacini, text="zadejte nacini ktere chcete smazat:")
        self.nazev_nacini.grid(row=0, column=0, padx=1, pady=2)
        self.nazev_nacini.configure(background="#282828", foreground="lightgray")

        self.nazev_nacini_entry = ttk.Entry(self.delete_nacini)
        self.nazev_nacini_entry.grid(row=1, column=0, padx=1, pady=2)

        self.odeslat_button = ttk.Button(self.delete_nacini, text="Odeslat", command=self.d_nacini)
        self.odeslat_button.grid(row=2, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.delete_nacini, text="Help", command=self.d_informace_nacini)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def zavri_insert_nacini(self):
        """
        tato metoda zavře okno pro insert nacini
        :return:nevrací nic
        """
        self.insert_nacini.destroy()

    def zavri_update_nacini(self):
        """
        tato metoda zavře okno pro update nacini
        :return:nevrací nic
        """
        self.update_nacini.destroy()

    def zavri_delete_nacini(self):
        """
        tato metoda zavře okno pro delete nacini
        :return:nevrací nic
        """
        self.delete_nacini.destroy()

    def i_informace_nacini(self):
        messagebox.showinfo("Info","Pro úspěšný insert vyplňte správně všechny kolonky")

    def u_informace_nacini(self):
        messagebox.showinfo("Info","Pro úspěšný update zvolte řádek, který chcete změnit a poté vyplňte správně kolonky")

    def d_informace_nacini(self):
        messagebox.showinfo("Info","Pro úspěšný delete vyplňte správně název")

    def i_nacini(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro insert nacini ošetří je regurelníma výrazama a poté je
        vloží do insert statementu pokud se insert provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        pokud uživatel zadá určitý atribut který musí být pro každý záznam unikátní tak na neho vyskočí okénko že musí
        být daný atribut unikátní
        :return: nevrací nic
        """
        i_nazev_nacini = self.nazev_nacini_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_nazev_nacini):
            messagebox.showerror("chyba", "Nacini může obsahovat pouze písmena a mezery")
            raise ValueError('Nacini musí obsahovat pouze písmena a mezery')
        i_kategorii_nacini = self.kategorii_nacini_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_kategorii_nacini):
            messagebox.showerror("chyba", "kategorie může obsahovat pouze písmena a mezery")
            raise ValueError('kategorie musí obsahovat pouze písmena a mezery')
        i_vyrobce = self.vyrobce_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_vyrobce):
            messagebox.showerror("chyba", "vyrobce může obsahovat pouze písmena a mezery")
            raise ValueError('vyrobce musí obsahovat pouze písmena a mezery')

        insert_statement = f"insert into nacini(nazev_nacini, kategorii_nacini, vyrobce) values(%s,%s,%s)"
        values = (i_nazev_nacini, i_kategorii_nacini, i_vyrobce)

        self.cursor.execute(insert_statement, values)
        self.connection.commit()
        messagebox.showinfo("Insert", "Přidali jste do tabulky nacini")
        self.zavri_insert_nacini()


    def u_nacini(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro update nacini ošetří je regurelníma výrazama a poté je
        vloží do update statementu pokud se update provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        a okno se zavře
        :return: nevraci nic
        """
        u_atribut = self.atribut_variable.get()
        u_uprava_atributu = self.uprava_atributu_entry.get()
        u_nazev_nacini = self.nazev_nacini_entry.get()

        if u_atribut == "nazev_nacini":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "Nacini může obsahovat pouze písmena a mezery")
                raise ValueError('Nacini musí obsahovat pouze písmena a mezery')
        elif u_atribut == "kategorii_nacini":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "kategorie může obsahovat pouze písmena a mezery")
                raise ValueError('kategorie musí obsahovat pouze písmena a mezery')
        elif u_atribut == "vyrobce":
            if not re.match(r'^[a-zA-Z0-9]{5}$', u_uprava_atributu):
                messagebox.showerror("chyba", "vyrobce může obsahovat pouze písmena a mezery")
                raise ValueError('vyrobce musí obsahovat pouze písmena a mezery')

        update_statement = f"update nacini set {u_atribut} = '{u_uprava_atributu}' where nazev_nacini = '{u_nazev_nacini}'"
        self.cursor.execute(update_statement)
        self.connection.commit()
        messagebox.showinfo("Update", "Upravili jste tabulku nacini")
        self.zavri_update_nacini()

    def d_nacini(self):
        """
        Tato tabulka vezme nazev nacini z formuláře pro delete z tabulky nacini zkontroluje ho a dosadí ho do
        delete statementu a delete provede
        :return: nevraci nic
        """
        d_nazev_nacini = self.nazev_nacini_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', d_nazev_nacini):
            messagebox.showerror("chyba", "Nacini může obsahovat pouze písmena a mezery")
            raise ValueError('Nacini musí obsahovat pouze písmena a mezery')

        delete_statement = f"delete from nacini where nazev_nacini = '{d_nazev_nacini}'"
        self.cursor.execute(delete_statement)
        self.connection.commit()
        messagebox.showinfo("Delete", "Vymazali jste z tabulky nacini")
        self.zavri_delete_nacini()
