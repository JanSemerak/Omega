import re
import tkinter as tk
from tkinter import ttk

import mysql.connector
from ttkthemes import ThemedTk
from tkinter import messagebox

from DatabaseConnection import DatabaseConnection


class Pacient(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

    def pacient_button(self):
        """
        Tato metoda vytváří okno které obsahuje tabulku Pacientů a tlačítka pro insert, update a delete tlačítko
        které okno zavře a do menu
        :return: nevrací nic
        """
        self.cursor.execute("SELECT pacient.id_pacient, pacient.jmeno_pacient, pacient.prijmeni_pacient, pacient.rodne_cislo_pacient, pacient.telefonni_cislo_pacient, pacient.ulice_pacient, pacient.mesto_pacient, pacient.cislo_popisne_pacient, pacient.psc_pacient, pacient.id_pojistovna FROM pacient")
        rows = self.cursor.fetchall()

        pacient = ThemedTk()
        pacient.title("pacienti")
        pacient.geometry("1920x1080")
        pacient.configure(background="#282828")
        style = ttk.Style(pacient)
        style.theme_use("equilux")

        self.pacient_main_frame = tk.Frame(pacient)
        self.pacient_main_frame.grid(row=1, column=0, padx=0, pady=200)
        self.pacient_main_frame.configure(background="#282828")

        self.pacient = ttk.Label(self.pacient_main_frame, text="Tabulka Pacient")
        self.pacient.grid(row=0)
        self.pacient.configure(background="#282828", padding=20, font=("Helvetica", 40, "bold"), foreground="white")

        self.table_frame = tk.Frame(self.pacient_main_frame)
        self.table_frame.grid(row=1, column=0, padx=0, pady=5)
        self.table_frame.configure(background="#282828")

        table = ttk.Treeview(self.table_frame, columns=(
            "jmeno_pacient", "prijmeni_pacient", "rodne_cislo_pacient", "telefonni_cislo_pacient", "ulice_pacient", "mesto_pacient", "cislo_popisne_pacient", "psc_pacient", "id_pojistovna"))

        table.heading("#0", text="ID")
        table.heading("jmeno_pacient", text="jmeno")
        table.heading("prijmeni_pacient", text="prijmeni")
        table.heading("rodne_cislo_pacient", text="rodne_cislo")
        table.heading("telefonni_cislo_pacient", text="telefonni_cislo")
        table.heading("ulice_pacient", text="ulice")
        table.heading("mesto_pacient", text="mesto")
        table.heading("cislo_popisne_pacient", text="cislo_popisne")
        table.heading("psc_pacient", text="psc")
        table.heading("id_pojistovna", text="pojistovna")

        for row in rows:
            table.insert("", "end", text=row[0], values=(row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9]))

        table.grid(row=1, pady=5, padx=0)

        def zavri_pacienta():
            pacient.destroy()

        self.button_frame = tk.Frame(self.pacient_main_frame)
        self.button_frame.grid(row=2, column=0, padx=0, pady=5)
        self.button_frame.configure(background="#282828")

        self.zpet_button_frame = tk.Frame(self.pacient_main_frame)
        self.zpet_button_frame.grid(row=3, column=0, padx=0, pady=5)
        self.zpet_button_frame.configure(background="#282828")

        insert_pacienta = ttk.Button(self.button_frame, text="insert", command=self.insert_pacient_window)
        update_pacienta = ttk.Button(self.button_frame, text="update", command=self.update_pacient_window)
        delete_pacienta = ttk.Button(self.button_frame, text="delete", command=self.delete_pacient_window)
        zpet = ttk.Button(self.zpet_button_frame, text="zpet", command=zavri_pacienta)
        insert_pacienta.grid(padx=5,pady=5, row=2, column=0)
        update_pacienta.grid(padx=5,pady=5, row=2, column=1)
        delete_pacienta.grid(padx=5,pady=5, row=2, column=2)
        zpet.grid(pady=5, row=5, column=0)

    def insert_pacient_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vložení záznamu do tabulky pacient
        :return:nevrací nic
        """
        self.insert_pacient = ThemedTk()
        self.insert_pacient.title("insert_pacienta")
        self.insert_pacient.geometry("400x520")
        self.insert_pacient.configure(background="#282828")
        style = ttk.Style(self.insert_pacient)
        style.theme_use("equilux")

        self.pac = ttk.Label(self.insert_pacient, text="Insert Pacient")
        self.pac.grid(row=0)
        self.pac.configure(background="#282828", padding=20, font=("Helvetica", 20, "bold"), foreground="white")

        self.insert_pacient_main_frame = tk.Frame(self.insert_pacient)
        self.insert_pacient_main_frame.grid(row=1, column=0, padx=0, pady=5)
        self.insert_pacient_main_frame.configure(background="#282828")

        self.jmeno_pacient_frame = tk.Frame(self.insert_pacient_main_frame)
        self.jmeno_pacient_frame.grid(row=0, column=0, pady=5, padx=5, sticky= "ew")
        self.jmeno_pacient_frame.configure(background="#282828")

        self.jmeno_pacient_label = ttk.Label(self.jmeno_pacient_frame, text="jmeno pacienta:")
        self.jmeno_pacient_label.grid(row=0, column=0, padx=5, pady=5 ,sticky ="w")
        self.jmeno_pacient_label.configure(background="#282828", foreground="lightgray")

        self.jmeno_pacient_entry = ttk.Entry(self.jmeno_pacient_frame)
        self.jmeno_pacient_entry.grid(row=0, column=1, padx=5, pady=5)

        self.prijmeni_pacient_frame = tk.Frame(self.insert_pacient_main_frame)
        self.prijmeni_pacient_frame.grid(row=1, column=0, pady=5, padx=5,sticky= "ew")
        self.prijmeni_pacient_frame.configure(background="#282828")

        self.prijmeni_pacient_label = ttk.Label(self.prijmeni_pacient_frame, text="prijmeni pacienta:")
        self.prijmeni_pacient_label.grid(row=1, column=0, padx=5, pady=5,sticky ="w")
        self.prijmeni_pacient_label.configure(background="#282828", foreground="lightgray")

        self.prijmeni_pacient_entry = ttk.Entry(self.prijmeni_pacient_frame)
        self.prijmeni_pacient_entry.grid(row=1, column=1, padx=5, pady=5)

        self.rodne_cislo_pacient_frame = tk.Frame(self.insert_pacient_main_frame)
        self.rodne_cislo_pacient_frame.grid(row=2, column=0, pady=5, padx=5,sticky= "ew")
        self.rodne_cislo_pacient_frame.configure(background="#282828")

        self.rodne_cislo_pacient_label = ttk.Label(self.rodne_cislo_pacient_frame, text="rodne cislo pacienta:")
        self.rodne_cislo_pacient_label.grid(row=2, column=0, padx=5, pady=5,sticky ="w")
        self.rodne_cislo_pacient_label.configure(background="#282828", foreground="lightgray")

        self.rodne_cislo_pacient_entry = ttk.Entry(self.rodne_cislo_pacient_frame)
        self.rodne_cislo_pacient_entry.grid(row=2, column=1, padx=5, pady=5)

        self.telefonni_cislo_pacient_frame = tk.Frame(self.insert_pacient_main_frame)
        self.telefonni_cislo_pacient_frame.grid(row=3, column=0, pady=5, padx=5,sticky= "ew")
        self.telefonni_cislo_pacient_frame.configure(background="#282828")

        self.telefonni_cislo_pacient_label = ttk.Label(self.telefonni_cislo_pacient_frame, text="telefonni cislo pacienta:")
        self.telefonni_cislo_pacient_label.grid(row=3, column=0, padx=5, pady=5,sticky ="w")
        self.telefonni_cislo_pacient_label.configure(background="#282828", foreground="lightgray")

        self.telefonni_cislo_pacient_entry = ttk.Entry(self.telefonni_cislo_pacient_frame)
        self.telefonni_cislo_pacient_entry.grid(row=3, column=1, padx=5, pady=5)

        self.ulice_pacient_frame = tk.Frame(self.insert_pacient_main_frame)
        self.ulice_pacient_frame.grid(row=4, column=0, pady=5, padx=5,sticky= "ew")
        self.ulice_pacient_frame.configure(background="#282828")

        self.ulice_pacient_label = ttk.Label(self.ulice_pacient_frame, text="ulice pacienta:")
        self.ulice_pacient_label.grid(row=4, column=0, padx=5, pady=5,sticky ="w")
        self.ulice_pacient_label.configure(background="#282828", foreground="lightgray")

        self.ulice_pacient_entry = ttk.Entry(self.ulice_pacient_frame)
        self.ulice_pacient_entry.grid(row=4, column=1, padx=5, pady=5)

        self.mesto_pacient_frame = tk.Frame(self.insert_pacient_main_frame)
        self.mesto_pacient_frame.grid(row=5, column=0, pady=5, padx=5,sticky= "ew")
        self.mesto_pacient_frame.configure(background="#282828")

        self.mesto_pacient_label = ttk.Label(self.mesto_pacient_frame, text="mesto pacienta:")
        self.mesto_pacient_label.grid(row=5, column=0, padx=5, pady=5,sticky ="w")
        self.mesto_pacient_label.configure(background="#282828", foreground="lightgray")

        self.mesto_pacient_entry = ttk.Entry(self.mesto_pacient_frame)
        self.mesto_pacient_entry.grid(row=5, column=1, padx=5, pady=5)

        self.cislo_popisne_pacient_frame = tk.Frame(self.insert_pacient_main_frame)
        self.cislo_popisne_pacient_frame.grid(row=6, column=0, pady=5, padx=5,sticky= "ew")
        self.cislo_popisne_pacient_frame.configure(background="#282828")

        self.cislo_popisne_pacient_label = ttk.Label(self.cislo_popisne_pacient_frame, text="cislo popisne pacienta:")
        self.cislo_popisne_pacient_label.grid(row=6, column=0, padx=5, pady=5,sticky ="w")
        self.cislo_popisne_pacient_label.configure(background="#282828", foreground="lightgray")

        self.cislo_popisne_pacient_entry = ttk.Entry(self.cislo_popisne_pacient_frame)
        self.cislo_popisne_pacient_entry.grid(row=6, column=1, padx=5, pady=5)

        self.psc_pacient_frame = tk.Frame(self.insert_pacient_main_frame)
        self.psc_pacient_frame.grid(row=7, column=0, pady=5, padx=5,sticky= "ew")
        self.psc_pacient_frame.configure(background="#282828")

        self.psc_pacient_label = ttk.Label(self.psc_pacient_frame, text="psc pacienta:")
        self.psc_pacient_label.grid(row=7, column=0, padx=5, pady=5,sticky ="w")
        self.psc_pacient_label.configure(background="#282828", foreground="lightgray")

        self.psc_pacient_entry = ttk.Entry(self.psc_pacient_frame)
        self.psc_pacient_entry.grid(row=7, column=1, padx=5, pady=5)

        self.id_pojistovna_frame = tk.Frame(self.insert_pacient_main_frame)
        self.id_pojistovna_frame.grid(row=8, column=0, pady=5, padx=5,sticky= "ew")
        self.id_pojistovna_frame.configure(background="#282828")

        self.id_pojistovna_label = ttk.Label(self.id_pojistovna_frame, text="id pojistovny:")
        self.id_pojistovna_label.grid(row=8, column=0, padx=5, pady=5,sticky ="w")
        self.id_pojistovna_label.configure(background="#282828", foreground="lightgray")

        self.id_pojistovna_entry = ttk.Entry(self.id_pojistovna_frame)
        self.id_pojistovna_entry.grid(row=8, column=1, padx=5, pady=5)

        self.odeslat_button = ttk.Button(self.insert_pacient, text="Odeslat", command=self.i_pacient)
        self.odeslat_button.grid(row=9, column=0, columnspan=1, padx=5, pady=5)

        self.help_button = ttk.Button(self.insert_pacient, text="Help", command=self.i_informace_pacient)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def update_pacient_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro upravení záznamu v tabulce pacient
        :return:nevrací nic
        """
        self.update_pacient = ThemedTk()
        self.update_pacient.title("update pacienta")
        self.update_pacient.geometry("360x250")
        self.update_pacient.configure(background="#282828")
        style = ttk.Style(self.update_pacient)
        style.theme_use("equilux")

        self.atribut = ttk.Label(self.update_pacient, text="atribut který chcete upravit v tabulce pacient:")
        self.atribut.grid(row=0, column=0, padx=1, pady=2)
        self.atribut.configure(background="#282828", foreground="lightgray")

        self.atribut = ["jmeno_pacient", "prijmeni_pacient", "rodne_cislo_pacient", "telefonni_cislo_pacient", "ulice_pacient", "mesto_pacient", "cislo_popisne_pacient", "psc_pacient", "id_pojistovna"]
        self.atribut_variable = tk.StringVar(self.update_pacient)
        self.atribut_variable.set(self.atribut[0])
        self.dropdown = ttk.OptionMenu(self.update_pacient, self.atribut_variable, *self.atribut)
        self.dropdown.grid(row=1, column=0, padx=1, pady=2)

        self.uprava_atributu = ttk.Label(self.update_pacient, text="na co chcete daný atribut opravit:")
        self.uprava_atributu.grid(row=2, column=0, padx=1, pady=2)
        self.uprava_atributu.configure(background="#282828", foreground="lightgray")

        self.uprava_atributu_entry = ttk.Entry(self.update_pacient)
        self.uprava_atributu_entry.grid(row=3, column=0, padx=1, pady=2)

        self.jmeno_pacienta = ttk.Label(self.update_pacient,text="jmeno pacienta u kterého chcete atribut upravit:")
        self.jmeno_pacienta.grid(row=4, column=0, padx=1, pady=2)
        self.jmeno_pacienta.configure(background="#282828", foreground="lightgray")

        self.jmeno_pacienta_entry = ttk.Entry(self.update_pacient)
        self.jmeno_pacienta_entry.grid(row=5, column=0, padx=1, pady=2)

        self.login_button = ttk.Button(self.update_pacient, text="Odeslat", command=self.u_pacient)
        self.login_button.grid(row=6, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.update_pacient, text="Help", command=self.u_informace_pacient)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def delete_pacient_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vymazání záznamu z tabulky pacient
        :return:nevrací nic
        """
        self.delete_pacient = ThemedTk()
        self.delete_pacient.title("delete pacient")
        self.delete_pacient.configure(background="#282828")
        style = ttk.Style(self.delete_pacient)
        style.theme_use("equilux")

        self.jmeno_pacienta = ttk.Label(self.delete_pacient, text="zadejte jmeno pacienta kterého chcete smazat:")
        self.jmeno_pacienta.grid(row=0, column=0, padx=1, pady=2)
        self.jmeno_pacienta.configure(background="#282828", foreground="lightgray")

        self.jmeno_pacienta_entry = ttk.Entry(self.delete_pacient)
        self.jmeno_pacienta_entry.grid(row=1, column=0, padx=1, pady=2)

        self.odeslat_button = ttk.Button(self.delete_pacient, text="Odeslat", command=self.d_pacient)
        self.odeslat_button.grid(row=2, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.delete_pacient, text="Help", command=self.d_informace_pacient)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def zavri_insert_pacient(self):
        """
        tato metoda zavře okno pro insert pacient
        :return:nevrací nic
        """
        self.insert_pacient.destroy()

    def zavri_update_pacient(self):
        """
        tato metoda zavře okno pro update pacient
        :return:nevrací nic
        """
        self.update_pacient.destroy()

    def zavri_delete_pacient(self):
        """
        tato metoda zavře okno pro delete pacient
        :return:nevrací nic
        """
        self.delete_pacient.destroy()

    def i_informace_pacient(self):
        messagebox.showinfo("Info","Pro úspěšný insert vyplňte správně všechny kolonky")

    def u_informace_pacient(self):
        messagebox.showinfo("Info","Pro úspěšný update zvolte řádek, který chcete změnit a poté vyplňte správně kolonky")

    def d_informace_pacient(self):
        messagebox.showinfo("Info","Pro úspěšný delete vyplňte správně název")

    def i_pacient(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro insert pacient ošetří je regurelníma výrazama a poté je
        vloží do insert statementu pokud se insert provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        pokud uživatel zadá určitý atribut který musí být pro každý záznam unikátní tak na neho vyskočí okénko že musí
        být daný atribut unikátní
        :return: nevrací nic
        """
        i_jmeno_pacient = self.jmeno_pacient_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_jmeno_pacient):
            messagebox.showerror("chyba", "Jméno pacienta může obsahovat pouze písmena a mezery")
            raise ValueError('Jméno pacienta musí obsahovat pouze písmena a mezery')
        i_prijmeni_pacient = self.prijmeni_pacient_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_prijmeni_pacient):
            messagebox.showerror("chyba", "Prijmeni pacienta může obsahovat pouze písmena a mezery")
            raise ValueError('Prijmeni pacienta musí obsahovat pouze písmena a mezery')
        i_rodne_cislo_pacient = self.rodne_cislo_pacient_entry.get()
        if not re.match(r'^[a-zA-Z0-9]{11}$', i_rodne_cislo_pacient):
            messagebox.showerror("chyba", "Rodné číslo musí obsahovat přesně 11 znaků")
            raise ValueError('Rodné číslo musí obsahovat právě 11 znaků')
        i_telefonni_cislo_pacient = self.telefonni_cislo_pacient_entry.get()
        if not re.match(r'^\d{9}$', i_telefonni_cislo_pacient):
            messagebox.showerror("chyba", "Telefon musí obsahovat přesně 9 číslic")
            raise ValueError('Telefon musí obsahovat právě 9 číslic')
        i_ulice_pacient = self.ulice_pacient_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_ulice_pacient):
            messagebox.showerror("chyba", "Ulice může obsahovat pouze písmena a mezery")
            raise ValueError('Ulice musí obsahovat pouze písmena a mezery')
        i_mesto_pacient = self.mesto_pacient_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_mesto_pacient):
            messagebox.showerror("chyba", "Mesto může obsahovat pouze písmena a mezery")
            raise ValueError('Mesto musí obsahovat pouze písmena a mezery')
        i_cislo_popisne_pacient = int(self.cislo_popisne_pacient_entry.get())
        i_psc_pacient = int(self.psc_pacient_entry.get())
        i_id_pojistovna = int(self.id_pojistovna_entry.get())

        try:
            insert_statement = f"insert into pacient(jmeno_pacient, prijmeni_pacient, rodne_cislo_pacient, telefonni_cislo_pacient, ulice_pacient, mesto_pacient, cislo_popisne_pacient, psc_pacient, id_pojistovna) values(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            values = (i_jmeno_pacient, i_prijmeni_pacient, i_rodne_cislo_pacient, i_telefonni_cislo_pacient, i_ulice_pacient, i_mesto_pacient, i_cislo_popisne_pacient, i_psc_pacient, i_id_pojistovna)

            self.cursor.execute(insert_statement, values)
            self.connection.commit()
            messagebox.showinfo("Insert", "Přidali jste do tabulky Pacient")
            self.zavri_insert_pacient()
        except mysql.connector.errors.IntegrityError:
            messagebox.showerror("Chyba","Telefonni cislo a Rodne cislo musi byt unikatni ")

    def u_pacient(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro update pacient ošetří je regurelníma výrazama a poté je
        vloží do update statementu pokud se update provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        a okno se zavře
        :return: nevraci nic
        """
        u_atribut = self.atribut_variable.get()
        u_uprava_atributu = self.uprava_atributu_entry.get()
        u_jmeno_pacienta = self.jmeno_pacienta_entry.get()

        if u_atribut == "jmeno_pacient":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "Jméno pacienta může obsahovat pouze písmena a mezery")
                raise ValueError('Jméno lékaře musí obsahovat pouze písmena a mezery')
        elif u_atribut == "prijmeni_pacient":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "Příjmení pacienta může obsahovat pouze písmena a mezery")
                raise ValueError('Příjmení lékaře musí obsahovat pouze písmena a mezery')
        elif u_atribut == "rodne_cislo_pacient":
            if not re.match(r'^[a-zA-Z0-9]{11}$', u_uprava_atributu):
                messagebox.showerror("chyba", "Rodne číslo musí obsahovat přesně 5 znaků")
                raise ValueError('Rodne číslo musí obsahovat právě 5 znaků')
        elif u_atribut == "telefonni_cislo_pacient":
            if not re.match(r'^\d{9}$', u_uprava_atributu):
                messagebox.showerror("chyba", "Telefon musí obsahovat přesně 9 číslic")
                raise ValueError('Telefon musí obsahovat právě 9 číslic')

        update_statement = f"update pacient set {u_atribut} = '{u_uprava_atributu}' where jmeno_pacient = '{u_jmeno_pacienta}'"
        self.cursor.execute(update_statement)
        self.connection.commit()
        messagebox.showinfo("Update", "Upravili jste tabulku Pacient")
        self.zavri_update_pacient()

    def d_pacient(self):
        """
        Tato tabulka vezme jméno pacient z formuláře pro delete z tabulky pacient zkontroluje ho a dosadí ho do
        delete statementu a delete provede
        :return: nevraci nic
        """
        d_jmeno_pacienta = self.jmeno_pacienta_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', d_jmeno_pacienta):
            messagebox.showerror("chyba", "Jméno pacienta může obsahovat pouze písmena a mezery")
            raise ValueError('Jméno pacienta musí obsahovat pouze písmena a mezery')

        delete_statement = f"delete from pacient where jmeno_pacient = '{d_jmeno_pacienta}'"
        self.cursor.execute(delete_statement)
        self.connection.commit()
        messagebox.showinfo("Delete", "Vymazali jste z tabulky Pacient")
        self.zavri_delete_pacient()
