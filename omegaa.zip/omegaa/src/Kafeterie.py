import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
from tkinter import messagebox
import re
from DatabaseConnection import DatabaseConnection


class Kafeterie(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

    def kafeterie_button(self):
        """
        Tato metoda vytváří okno které obsahuje tabulku Kafeterie a tlačítka pro insert, update a delete tlačítko
        které okno zavře a do menu
        :return: nevrací nic
        """
        self.cursor.execute("SELECT kafeterie.id_kafeterie, kafeterie.nazev_jidla, kafeterie.cena, kafeterie.rozmer, kafeterie.pocet_zamestnancu FROM kafeterie")
        rows = self.cursor.fetchall()

        kafeterie = ThemedTk()
        kafeterie.title("kafeterie")
        kafeterie.geometry("1920x1080")
        kafeterie.configure(background="#282828")
        kafeterie.configure(background="#282828")
        style = ttk.Style(kafeterie)
        style.theme_use("equilux")

        self.kafeterie_main_frame = tk.Frame(kafeterie)
        self.kafeterie_main_frame.grid(row=1, column=0, padx=250, pady=200)
        self.kafeterie_main_frame.configure(background="#282828")

        self.kafeterie = ttk.Label(self.kafeterie_main_frame, text="Tabulka kafeterie")
        self.kafeterie.grid(row=0)
        self.kafeterie.configure(background="#282828", padding=20, font=("Helvetica", 40, "bold"), foreground="white")

        self.table_frame = tk.Frame(self.kafeterie_main_frame)
        self.table_frame.grid(row=1, column=0, padx=10, pady=5)
        self.table_frame.configure(background="#282828")

        table = ttk.Treeview(self.table_frame, columns=(
           "nazev_jidla", "cena", "rozmer", "pocet_zamestnancu"))

        table.heading("#0", text="ID")
        table.heading("nazev_jidla", text="nazev_jidla")
        table.heading("cena", text="cena")
        table.heading("rozmer", text="rozmer")
        table.heading("pocet_zamestnancu", text="pocet_zamestnancu")

        for row in rows:
            table.insert("", "end", text=row[0], values=(row[1], row[2], row[3], row[4]))

        table.grid(row=1, pady=5, padx=210)

        def zavri_kafeterii():
            kafeterie.destroy()

        self.button_frame = tk.Frame(self.kafeterie_main_frame)
        self.button_frame.grid(row=2, column=0, padx=0, pady=5)
        self.button_frame.configure(background="#282828")

        self.zpet_button_frame = tk.Frame(self.kafeterie_main_frame)
        self.zpet_button_frame.grid(row=3, column=0, padx=0, pady=5)
        self.zpet_button_frame.configure(background="#282828")

        insert_kafeterie = ttk.Button(self.button_frame, text="insert", command=self.insert_kafeterie_window)
        update_kafeterie = ttk.Button(self.button_frame, text="update", command=self.update_kafeterie_window)
        delete_kafeterie = ttk.Button(self.button_frame, text="delete", command=self.delete_kafeterie_window)
        zpet = ttk.Button(self.zpet_button_frame, text="zpet", command=zavri_kafeterii)
        insert_kafeterie.grid(padx=5,pady=5, row=2, column=0)
        update_kafeterie.grid(padx=5,pady=5, row=2, column=1)
        delete_kafeterie.grid(padx=5,pady=5, row=2, column=2)
        zpet.grid(pady=5, row=5, column=0)

    def insert_kafeterie_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vložení záznamu do tabulky kafeterie
        :return:nevrací nic
        """
        self.insert_kafeterie = ThemedTk()
        self.insert_kafeterie.title("insert kafeterie")
        self.insert_kafeterie.geometry("400x350")
        self.insert_kafeterie.configure(background="#282828")
        style = ttk.Style(self.insert_kafeterie)
        style.theme_use("equilux")

        self.kaf = ttk.Label(self.insert_kafeterie, text="insert kafeterie")
        self.kaf.grid(row=0)
        self.kaf.configure(background="#282828", padding=20, font=("Helvetica", 20, "bold"), foreground="white")

        self.insert_kafeterie_main_frame = tk.Frame(self.insert_kafeterie)
        self.insert_kafeterie_main_frame.grid(row=1, column=0, padx=0, pady=5)
        self.insert_kafeterie_main_frame.configure(background="#282828")

        self.nazev_jidla_frame = tk.Frame(self.insert_kafeterie_main_frame)
        self.nazev_jidla_frame.grid(row=0, column=0, pady=5, padx=5, sticky="ew")
        self.nazev_jidla_frame.configure(background="#282828")

        self.nazev_jidla_label = ttk.Label(self.nazev_jidla_frame, text="nazev jidla:")
        self.nazev_jidla_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.nazev_jidla_label.configure(background="#282828", foreground="lightgray")

        self.nazev_jidla_entry = ttk.Entry(self.nazev_jidla_frame)
        self.nazev_jidla_entry.grid(row=0, column=1, padx=5, pady=5)

        self.cena_frame = tk.Frame(self.insert_kafeterie_main_frame)
        self.cena_frame.grid(row=1, column=0, pady=5, padx=5, sticky="ew")
        self.cena_frame.configure(background="#282828")

        self.cena_label = ttk.Label(self.cena_frame, text="cena:")
        self.cena_label.grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.cena_label.configure(background="#282828", foreground="lightgray")

        self.cena_entry = ttk.Entry(self.cena_frame)
        self.cena_entry.grid(row=1, column=1, padx=5, pady=5)

        self.rozmer_frame = tk.Frame(self.insert_kafeterie_main_frame)
        self.rozmer_frame.grid(row=2, column=0, pady=5, padx=5, sticky="ew")
        self.rozmer_frame.configure(background="#282828")

        self.rozmer_label = ttk.Label(self.rozmer_frame, text="rozmer:")
        self.rozmer_label.grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.rozmer_label.configure(background="#282828", foreground="lightgray")

        self.rozmer_entry = ttk.Entry(self.rozmer_frame)
        self.rozmer_entry.grid(row=2, column=1, padx=5, pady=5)

        self.pocet_zamestnancu_frame = tk.Frame(self.insert_kafeterie_main_frame)
        self.pocet_zamestnancu_frame.grid(row=3, column=0, pady=5, padx=5, sticky="ew")
        self.pocet_zamestnancu_frame.configure(background="#282828")

        self.pocet_zamestnancu_label = ttk.Label(self.pocet_zamestnancu_frame, text="pocet zamestnancu:")
        self.pocet_zamestnancu_label.grid(row=3, column=0, padx=5, pady=5, sticky="w")
        self.pocet_zamestnancu_label.configure(background="#282828", foreground="lightgray")

        self.pocet_zamestnancu_entry = ttk.Entry(self.pocet_zamestnancu_frame)
        self.pocet_zamestnancu_entry.grid(row=3, column=1, padx=5, pady=5)

        self.odeslat_button = ttk.Button(self.insert_kafeterie, text="Odeslat", command=self.i_kafeterie)
        self.odeslat_button.grid(row=4, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.insert_kafeterie, text="Help", command=self.i_informace_kafeterie)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def update_kafeterie_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro upravení záznamu v tabulce kafeterie
        :return:nevrací nic
        """
        self.update_kafeterie = ThemedTk()
        self.update_kafeterie.title("update kafeterie")
        self.update_kafeterie.geometry("360x210")
        self.update_kafeterie.configure(background="#282828")
        style = ttk.Style(self.update_kafeterie)
        style.theme_use("equilux")

        self.atribut = ttk.Label(self.update_kafeterie, text="atribut který chcete upravit v tabulce kafeterie:")
        self.atribut.grid(row=0, column=0, padx=1, pady=2)
        self.atribut.configure(background="#282828", foreground="lightgray")

        self.atribut = ["nazev_jidla", "cena", "rozmer", "pocet_zamestnancu"]
        self.atribut_variable = tk.StringVar(self.update_kafeterie)
        self.atribut_variable.set(self.atribut[0])
        self.dropdown = ttk.OptionMenu(self.update_kafeterie, self.atribut_variable, *self.atribut)
        self.dropdown.grid(row=1, column=0, padx=1, pady=2)

        self.uprava_atributu = ttk.Label(self.update_kafeterie, text="na co chcete daný atribut opravit:")
        self.uprava_atributu.grid(row=2, column=0, padx=1, pady=2)
        self.uprava_atributu.configure(background="#282828", foreground="lightgray")

        self.uprava_atributu_entry = ttk.Entry(self.update_kafeterie)
        self.uprava_atributu_entry.grid(row=3, column=0, padx=1, pady=2)

        self.nazev_jidla = ttk.Label(self.update_kafeterie,text="nazev jidla u které chcete atribut upravit:")
        self.nazev_jidla.grid(row=4, column=0, padx=1, pady=2)
        self.nazev_jidla.configure(background="#282828", foreground="lightgray")

        self.nazev_jidla_entry = ttk.Entry(self.update_kafeterie)
        self.nazev_jidla_entry.grid(row=5, column=0, padx=1, pady=2)

        self.login_button = ttk.Button(self.update_kafeterie, text="Odeslat", command=self.i_kafeterie)
        self.login_button.grid(row=6, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.update_kafeterie, text="Help", command=self.u_informace_kafeterie)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def delete_kafeterie_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vymazání záznamu z tabulky kafeterie
        :return:nevrací nic
        """
        self.delete_kafeterie = ThemedTk()
        self.delete_kafeterie.title("delete kafeterie")
        self.delete_kafeterie.configure(background="#282828")
        style = ttk.Style(self.delete_kafeterie)
        style.theme_use("equilux")

        self.nazev_jidla = ttk.Label(self.delete_kafeterie, text="zadejte nazev_jidla kterou chcete smazat:")
        self.nazev_jidla.grid(row=0, column=0, padx=1, pady=2)
        self.nazev_jidla.configure(background="#282828", foreground="lightgray")

        self.nazev_jidla_entry = ttk.Entry(self.delete_kafeterie)
        self.nazev_jidla_entry.grid(row=1, column=0, padx=1, pady=2)

        self.odeslat_button = ttk.Button(self.delete_kafeterie, text="Odeslat", command=self.d_kafeterie)
        self.odeslat_button.grid(row=2, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.delete_kafeterie, text="Help", command=self.d_informace_kafeterie)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def zavri_insert_kafeterie(self):
        """
        tato metoda zavře okno pro insert kafeterie
        :return:nevrací nic
        """
        self.insert_kafeterie.destroy()

    def zavri_update_kafeterie(self):
        """
        tato metoda zavře okno pro update kafeterie
        :return:nevrací nic
        """
        self.update_kafeterie.destroy()

    def zavri_delete_kafeterie(self):
        """
        tato metoda zavře okno pro delete kafeterie
        :return:nevrací nic
        """
        self.delete_kafeterie.destroy()

    def i_informace_kafeterie(self):
        messagebox.showinfo("Info","Pro úspěšný insert vyplňte správně všechny kolonky")

    def u_informace_kafeterie(self):
        messagebox.showinfo("Info","Pro úspěšný update zvolte řádek, který chcete změnit a poté vyplňte správně kolonky")

    def d_informace_kafeterie(self):
        messagebox.showinfo("Info","Pro úspěšný delete vyplňte správně název")

    def i_kafeterie(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro insert kafeterie ošetří je regurelníma výrazama a poté je
        vloží do insert statementu pokud se insert provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        pokud uživatel zadá určitý atribut který musí být pro každý záznam unikátní tak na neho vyskočí okénko že musí
        být daný atribut unikátní
        :return: nevrací nic
        """
        i_nazev_jidla = self.nazev_jidla_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_nazev_jidla):
            messagebox.showerror("chyba", "nazev jidlo může obsahovat pouze písmena a mezery")
            raise ValueError('nazev jidla musí obsahovat pouze písmena a mezery')
        i_cena = int(self.cena_entry.get())
        i_rozmer = int(self.rozmer_entry.get())
        i_pocet_zamestnancu = int(self.pocet_zamestnancu_entry.get())

        insert_statement = f"insert into kafeterie(nazev_jidla, cena, rozmer, pocet_zamestnancu) values(%s,%s,%s,%s)"
        values = (i_nazev_jidla, i_cena, i_rozmer, i_pocet_zamestnancu)
        self.cursor.execute(insert_statement, values)
        self.connection.commit()
        messagebox.showinfo("Insert", "Přidali jste do tabulky kafeterie")
        self.zavri_insert_kafeterie()


    def u_kafeterie(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro update kafeterie ošetří je regurelníma výrazama a poté je
        vloží do update statementu pokud se update provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        a okno se zavře
        :return: nevraci nic
        """
        u_atribut = self.atribut_variable.get()
        u_uprava_atributu = self.uprava_atributu_entry.get()
        u_nazev_jidla = self.nazev_jidla_entry.get()

        if u_atribut == "nazev_jidla":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "nazev_jidla může obsahovat pouze písmena a mezery")
                raise ValueError('nazev_jidla musí obsahovat pouze písmena a mezery')


        update_statement = f"update kafeterie set {u_atribut} = '{u_uprava_atributu}' where nazev_jidla = '{u_nazev_jidla}'"
        self.cursor.execute(update_statement)
        self.connection.commit()
        messagebox.showinfo("Update", "Upravili jste tabulku kafeterie")
        self.zavri_update_kafeterie()

    def d_kafeterie(self):
        """
        Tato tabulka vezme název jídla z formuláře pro delete z tabulky kafeterie zkontroluje ho a dosadí ho do
        delete statementu a delete provede
        :return: nevraci nic
        """
        d_nazev_jidla = self.nazev_jidla_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', d_nazev_jidla):
            messagebox.showerror("chyba", "nazev_jidla může obsahovat pouze písmena a mezery")
            raise ValueError('nazev_jidla musí obsahovat pouze písmena a mezery')

        delete_statement = f"delete from kafeterie where nazev_jidla = '{d_nazev_jidla}'"
        self.cursor.execute(delete_statement)
        self.connection.commit()
        messagebox.showinfo("Delete", "Vymazali jste z tabulky kafeterie")
        self.zavri_delete_kafeterie()
