from Okno import LoginWindow
import tkinter as tk

if __name__ == "main":
    root = tk.Tk()
    app = LoginWindow(master=root)
    app.mainloop()
