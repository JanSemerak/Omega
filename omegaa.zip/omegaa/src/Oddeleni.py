import re
import tkinter as tk
from tkinter import ttk

import mysql.connector
from ttkthemes import ThemedTk
from tkinter import messagebox
from DatabaseConnection import DatabaseConnection


class Oddeleni(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

    def oddeleni_button(self):
        """
        Tato metoda vytváří okno které obsahuje tabulku Oddeleni a tlačítka pro insert, update a delete tlačítko
        které okno zavře a do menu
        :return: nevrací nic
        """
        self.cursor.execute("SELECT oddeleni.id_oddeleni, oddeleni.nazev_oddeleni, oddeleni.telefonni_cislo_oddeleni, oddeleni.patro_oddeleni FROM oddeleni")
        rows = self.cursor.fetchall()

        oddeleni = ThemedTk()
        oddeleni.title("oddeleni")
        oddeleni.geometry("1920x1080")
        oddeleni.configure(background="#282828")
        style = ttk.Style(oddeleni)
        style.theme_use("equilux")

        self.oddeleni_main_frame = tk.Frame(oddeleni)
        self.oddeleni_main_frame.grid(row=1, column=0, padx=350, pady=200)
        self.oddeleni_main_frame.configure(background="#282828")

        self.oddeleni = ttk.Label(self.oddeleni_main_frame, text="Tabulka oddeleni")
        self.oddeleni.grid(row=0)
        self.oddeleni.configure(background="#282828", padding=20, font=("Helvetica", 40, "bold"), foreground="white")

        self.table_frame = tk.Frame(self.oddeleni_main_frame)
        self.table_frame.grid(row=1, column=0, padx=10, pady=5)
        self.table_frame.configure(background="#282828")

        table = ttk.Treeview(self.table_frame, columns=(
           "nazev_oddeleni", "telefonni_cislo_oddeleni", "patro_oddeleni"))

        table.heading("#0", text="ID")
        table.heading("nazev_oddeleni", text="nazev_oddeleni")
        table.heading("telefonni_cislo_oddeleni", text="telefonni_cislo_oddeleni")
        table.heading("patro_oddeleni", text="patro_oddeleni")

        for row in rows:
            table.insert("", "end", text=row[0], values=(row[1], row[2], row[3]))

        table.grid(row=1, pady=5, padx=210)

        def zavri_oddeleni():
            oddeleni.destroy()

        self.button_frame = tk.Frame(self.oddeleni_main_frame)
        self.button_frame.grid(row=2, column=0, padx=0, pady=5)
        self.button_frame.configure(background="#282828")

        self.zpet_button_frame = tk.Frame(self.oddeleni_main_frame)
        self.zpet_button_frame.grid(row=3, column=0, padx=0, pady=5)
        self.zpet_button_frame.configure(background="#282828")

        insert_oddeleni = ttk.Button(self.button_frame, text="insert", command=self.insert_oddeleni_window)
        update_oddeleni = ttk.Button(self.button_frame, text="update", command=self.update_oddeleni_window)
        delete_oddeleni = ttk.Button(self.button_frame, text="delete", command=self.delete_oddeleni_window)
        zpet = ttk.Button(self.zpet_button_frame, text="zpet", command=zavri_oddeleni)
        insert_oddeleni.grid(padx=5,pady=5, row=2, column=0)
        update_oddeleni.grid(padx=5,pady=5, row=2, column=1)
        delete_oddeleni.grid(padx=5,pady=5, row=2, column=2)
        zpet.grid(pady=5, row=5, column=0)

    def insert_oddeleni_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vložení záznamu do tabulky Oddeleni
        :return:nevrací nic
        """
        self.insert_oddeleni = ThemedTk()
        self.insert_oddeleni.title("insert_oddeleni")
        self.insert_oddeleni.geometry("340x280")
        self.insert_oddeleni.configure(background="#282828")
        style = ttk.Style(self.insert_oddeleni)
        style.theme_use("equilux")

        self.odd = ttk.Label(self.insert_oddeleni, text="Insert oddeleni")
        self.odd.grid(row=0)
        self.odd.configure(background="#282828", padding=20, font=("Helvetica", 20, "bold"), foreground="white")

        self.insert_oddeleni_main_frame = tk.Frame(self.insert_oddeleni)
        self.insert_oddeleni_main_frame.grid(row=1, column=0, padx=0, pady=5)
        self.insert_oddeleni_main_frame.configure(background="#282828")

        self.nazev_oddeleni_frame = tk.Frame(self.insert_oddeleni_main_frame)
        self.nazev_oddeleni_frame.grid(row=0, column=0, pady=5, padx=5, sticky= "ew")
        self.nazev_oddeleni_frame.configure(background="#282828")

        self.nazev_oddeleni_label = ttk.Label(self.nazev_oddeleni_frame, text="oddeleni:")
        self.nazev_oddeleni_label.grid(row=0, column=0, padx=5, pady=5,sticky ="w")
        self.nazev_oddeleni_label.configure(background="#282828", foreground="lightgray")

        self.nazev_oddeleni_entry = ttk.Entry(self.nazev_oddeleni_frame)
        self.nazev_oddeleni_entry.grid(row=0, column=1, padx=5, pady=5)

        self.telefonni_cislo_oddeleni_frame = tk.Frame(self.insert_oddeleni_main_frame)
        self.telefonni_cislo_oddeleni_frame.grid(row=1, column=0, pady=5, padx=5, sticky= "ew")
        self.telefonni_cislo_oddeleni_frame.configure(background="#282828")

        self.telefonni_cislo_oddeleni_label = ttk.Label(self.telefonni_cislo_oddeleni_frame, text="telefonni cislo:")
        self.telefonni_cislo_oddeleni_label.grid(row=1, column=0, padx=5, pady=5,sticky ="w")
        self.telefonni_cislo_oddeleni_label.configure(background="#282828", foreground="lightgray")

        self.telefonni_cislo_oddeleni_entry = ttk.Entry(self.telefonni_cislo_oddeleni_frame)
        self.telefonni_cislo_oddeleni_entry.grid(row=1, column=1, padx=5, pady=5)

        self.patro_oddeleni_frame = tk.Frame(self.insert_oddeleni_main_frame)
        self.patro_oddeleni_frame.grid(row=2, column=0, pady=5, padx=5, sticky= "ew")
        self.patro_oddeleni_frame.configure(background="#282828")

        self.patro_oddeleni_label = ttk.Label(self.patro_oddeleni_frame, text="patro:")
        self.patro_oddeleni_label.grid(row=2, column=0, padx=5, pady=5,sticky ="w")
        self.patro_oddeleni_label.configure(background="#282828", foreground="lightgray")

        self.patro_oddeleni_entry = ttk.Entry(self.patro_oddeleni_frame)
        self.patro_oddeleni_entry.grid(row=2, column=1, padx=5, pady=5)

        self.odeslat_button = ttk.Button(self.insert_oddeleni, text="Odeslat", command=self.i_oddeleni)
        self.odeslat_button.grid(row=3, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.insert_oddeleni, text="Help", command=self.i_informace_oddeleni)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def update_oddeleni_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro upravení záznamu v tabulce Oddeleni
        :return:nevrací nic
        """
        self.update_oddeleni = ThemedTk()
        self.update_oddeleni.title("update oddeleni")
        self.update_oddeleni.geometry("340x240")
        self.update_oddeleni.configure(background="#282828")
        style = ttk.Style(self.update_oddeleni)
        style.theme_use("equilux")

        self.atribut = ttk.Label(self.update_oddeleni, text="atribut který chcete upravit v tabulce oddeleni:")
        self.atribut.grid(row=0, column=0, padx=1, pady=2)
        self.atribut.configure(background="#282828", foreground="lightgray")

        self.atribut = ["nazev_oddeleni", "telefonni_cislo_oddeleni", "patro_oddeleni"]
        self.atribut_variable = tk.StringVar(self.update_oddeleni)
        self.atribut_variable.set(self.atribut[0])
        self.dropdown = ttk.OptionMenu(self.update_oddeleni, self.atribut_variable, *self.atribut)
        self.dropdown.grid(row=1, column=0, padx=1, pady=2)

        self.uprava_atributu = ttk.Label(self.update_oddeleni, text="na co chcete daný atribut opravit:")
        self.uprava_atributu.grid(row=2, column=0, padx=1, pady=2)
        self.uprava_atributu.configure(background="#282828", foreground="lightgray")

        self.uprava_atributu_entry = ttk.Entry(self.update_oddeleni)
        self.uprava_atributu_entry.grid(row=3, column=0, padx=1, pady=2)

        self.nazev_oddeleni = ttk.Label(self.update_oddeleni,text="oddeleni u kterého chcete atribut upravit:")
        self.nazev_oddeleni.grid(row=4, column=0, padx=1, pady=2)
        self.nazev_oddeleni.configure(background="#282828", foreground="lightgray")

        self.nazev_oddeleni_entry = ttk.Entry(self.update_oddeleni)
        self.nazev_oddeleni_entry.grid(row=5, column=0, padx=1, pady=2)

        self.login_button = ttk.Button(self.update_oddeleni, text="Odeslat", command=self.u_oddeleni)
        self.login_button.grid(row=6, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.update_oddeleni, text="Help", command=self.u_informace_oddeleni)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def delete_oddeleni_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vymazání záznamu z tabulky Oddeleni
        :return:nevrací nic
        """
        self.delete_oddeleni = ThemedTk()
        self.delete_oddeleni.title("delete_oddeleni")
        self.delete_oddeleni.configure(background="#282828")
        style = ttk.Style(self.delete_oddeleni)
        style.theme_use("equilux")

        self.nazev_oddeleni = ttk.Label(self.delete_oddeleni, text="zadejte oddeleni kterou chcete smazat:")
        self.nazev_oddeleni.grid(row=0, column=0, padx=1, pady=2)
        self.nazev_oddeleni.configure(background="#282828", foreground="lightgray")

        self.nazev_oddeleni_entry = ttk.Entry(self.delete_oddeleni)
        self.nazev_oddeleni_entry.grid(row=1, column=0, padx=1, pady=2)

        self.odeslat_button = ttk.Button(self.delete_oddeleni, text="Odeslat", command=self.d_oddeleni)
        self.odeslat_button.grid(row=2, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.delete_oddeleni, text="Help", command=self.d_informace_oddeleni)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def zavri_insert_oddeleni(self):
        """
        tato metoda zavře okno pro insert Oddeleni
        :return:nevrací nic
        """
        self.insert_oddeleni.destroy()

    def zavri_update_oddeleni(self):
        """
        tato metoda zavře okno pro update Oddeleni
        :return:nevrací nic
        """
        self.update_oddeleni.destroy()

    def zavri_delete_oddeleni(self):
        """
        tato metoda zavře okno pro delete Oddeleni
        :return:nevrací nic
        """
        self.delete_oddeleni.destroy()

    def i_informace_oddeleni(self):
        messagebox.showinfo("Info","Pro úspěšný insert vyplňte správně všechny kolonky")

    def u_informace_oddeleni(self):
        messagebox.showinfo("Info","Pro úspěšný update zvolte řádek, který chcete změnit a poté vyplňte správně kolonky")

    def d_informace_oddeleni(self):
        messagebox.showinfo("Info","Pro úspěšný delete vyplňte správně název")

    def i_oddeleni(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro insert Oddeleni ošetří je regurelníma výrazama a poté je
        vloží do insert statementu pokud se insert provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        pokud uživatel zadá určitý atribut který musí být pro každý záznam unikátní tak na neho vyskočí okénko že musí
        být daný atribut unikátní
        :return: nevrací nic
        """
        i_nazev_oddeleni = self.nazev_oddeleni_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_nazev_oddeleni):
            messagebox.showerror("chyba", "Oddeleni může obsahovat pouze písmena a mezery")
            raise ValueError('Oddeleni musí obsahovat pouze písmena a mezery')
        i_telefonni_cislo_oddeleni = self.telefonni_cislo_oddeleni_entry.get()
        if not re.match(r'^\d{9}$', i_telefonni_cislo_oddeleni):
            messagebox.showerror("chyba", "Telefon musí obsahovat přesně 9 číslic")
            raise ValueError('Telefon musí obsahovat právě 9 číslic')
        i_patro_oddeleni = int(self.patro_oddeleni_entry.get())
        try:
            insert_statement = f"insert into oddeleni(nazev_oddeleni, telefonni_cislo_oddeleni, patro_oddeleni) values(%s,%s,%s)"
            values = (i_nazev_oddeleni, i_telefonni_cislo_oddeleni, i_patro_oddeleni)

            self.cursor.execute(insert_statement, values)
            self.connection.commit()
            messagebox.showinfo("Insert", "Přidali jste do tabulky oddeleni")
            self.zavri_insert_oddeleni()
        except mysql.connector.errors.IntegrityError:
            messagebox.showerror("Chyba", "Telefonni cislo musi byt unikatni ")

    def u_oddeleni(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro update Oddeleni ošetří je regurelníma výrazama a poté je
        vloží do update statementu pokud se update provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        a okno se zavře
        :return: nevraci nic
        """
        u_atribut = self.atribut_variable.get()
        u_uprava_atributu = self.uprava_atributu_entry.get()
        u_nazev_oddeleni = self.nazev_oddeleni_entry.get()

        if u_atribut == "nazev_oddeleni":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "Oddeleni může obsahovat pouze písmena a mezery")
                raise ValueError('Oddeleni musí obsahovat pouze písmena a mezery')
        elif u_atribut == "telefonni_cislo_oddeleni":
            if not re.match(r'^\d{9}$', u_uprava_atributu):
                messagebox.showerror("chyba", "Telefon musí obsahovat přesně 9 číslic")
                raise ValueError('Telefon musí obsahovat právě 9 číslic')

        update_statement = f"update oddeleni set {u_atribut} = '{u_uprava_atributu}' where nazev_oddeleni = '{u_nazev_oddeleni}'"
        self.cursor.execute(update_statement)
        self.connection.commit()
        messagebox.showinfo("Update", "Upravili jste tabulku oddeleni")
        self.zavri_update_oddeleni()

    def d_oddeleni(self):
        """
        Tato tabulka vezme nazev oddeleni z formuláře pro delete z tabulky Oddeleni zkontroluje ho a dosadí ho do
        delete statementu a delete provede
        :return: nevraci nic
        """
        d_nazev_oddeleni = self.nazev_oddeleni_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', d_nazev_oddeleni):
            messagebox.showerror("chyba", "Oddeleni může obsahovat pouze písmena a mezery")
            raise ValueError('Oddeleni musí obsahovat pouze písmena a mezery')

        delete_statement = f"delete from oddeleni where nazev_oddeleni = '{d_nazev_oddeleni}'"
        self.cursor.execute(delete_statement)
        self.connection.commit()
        messagebox.showinfo("Delete", "Vymazali jste z tabulky oddeleni")
        self.zavri_delete_oddeleni()
