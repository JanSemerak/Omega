import re
import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
from tkinter import messagebox
from DatabaseConnection import DatabaseConnection


class Nemocnice(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

    def nemocnice_button(self):
        """
        Tato metoda vytváří okno které obsahuje tabulku Nemocnice a tlačítka pro insert, update a delete tlačítko
        které okno zavře a do menu
        :return: nevrací nic
        """
        self.cursor.execute("SELECT nemocnice.id_nemocnice, nemocnice.nazev_nemocnice, nemocnice.ulice_nemocnice, nemocnice.mesto_nemocnice, nemocnice.cislo_popisne_nemocnice, nemocnice.psc_nemocnice, nemocnice.id_kafeterie FROM nemocnice")
        rows = self.cursor.fetchall()

        nemocnice = ThemedTk()
        nemocnice.title("nemocnice")
        nemocnice.geometry("1920x1080")
        nemocnice.configure(background="#282828")
        style = ttk.Style(nemocnice)
        style.theme_use("equilux")

        self.nemocnice_main_frame = tk.Frame(nemocnice)
        self.nemocnice_main_frame.grid(row=1, column=0, padx=70, pady=200)
        self.nemocnice_main_frame.configure(background="#282828")

        self.nemocnice = ttk.Label(self.nemocnice_main_frame, text="Tabulka nemocnice")
        self.nemocnice.grid(row=0)
        self.nemocnice.configure(background="#282828", padding=20, font=("Helvetica", 40, "bold"), foreground="white")

        self.table_frame = tk.Frame(self.nemocnice_main_frame)
        self.table_frame.grid(row=1, column=0, padx=10, pady=5)
        self.table_frame.configure(background="#282828")

        table = ttk.Treeview(self.table_frame, columns=(
            "nazev_nemocnice", "ulice_nemocnice", "mesto_nemocnice", "cislo_popisne_nemocnice", "psc_nemocnice","id_kafeterie"))

        table.heading("#0", text="ID")
        table.heading("nazev_nemocnice", text="nazev_nemocnice")
        table.heading("ulice_nemocnice", text="ulice_nemocnice")
        table.heading("mesto_nemocnice", text="mesto_nemocnice")
        table.heading("cislo_popisne_nemocnice", text="cislo_popisne_nemocnice")
        table.heading("psc_nemocnice", text="psc_nemocnice")
        table.heading("id_kafeterie", text="id_kafeterie")

        for row in rows:
            table.insert("", "end", text=row[0], values=(row[1], row[2], row[3], row[4], row[5], row[6]))

        table.grid(row=1, pady=5, padx=210)

        def zavri_nemocnici():
            nemocnice.destroy()

        self.button_frame = tk.Frame(self.nemocnice_main_frame)
        self.button_frame.grid(row=2, column=0, padx=0, pady=5)
        self.button_frame.configure(background="#282828")

        self.zpet_button_frame = tk.Frame(self.nemocnice_main_frame)
        self.zpet_button_frame.grid(row=3, column=0, padx=0, pady=5)
        self.zpet_button_frame.configure(background="#282828")

        insert_nemocnice = ttk.Button(self.button_frame, text="insert", command=self.insert_nemocnice_window)
        update_nemocnice = ttk.Button(self.button_frame, text="update", command=self.update_nemocnice_window)
        delete_nemocnice = ttk.Button(self.button_frame, text="delete", command=self.delete_nemocnice_window)
        zpet = ttk.Button(self.zpet_button_frame, text="zpet", command=zavri_nemocnici)
        insert_nemocnice.grid(padx=5,pady=5, row=2, column=0)
        update_nemocnice.grid(padx=5,pady=5, row=2, column=1)
        delete_nemocnice.grid(padx=5,pady=5, row=2, column=2)
        zpet.grid(pady=5, row=5, column=0)

    def insert_nemocnice_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vložení záznamu do tabulky Nemocnice
        :return:nevrací nic
        """
        self.insert_nemocnice = ThemedTk()
        self.insert_nemocnice.title("insert_nemocnice")
        self.insert_nemocnice.geometry("400x380")
        self.insert_nemocnice.configure(background="#282828")
        style = ttk.Style(self.insert_nemocnice)
        style.theme_use("equilux")

        self.nem = ttk.Label(self.insert_nemocnice, text="Insert nemocnice")
        self.nem.grid(row=0)
        self.nem.configure(background="#282828", padding=20, font=("Helvetica", 20, "bold"), foreground="white")

        self.insert_nemocnice_main_frame = tk.Frame(self.insert_nemocnice)
        self.insert_nemocnice_main_frame.grid(row=1, column=0, padx=0, pady=5)
        self.insert_nemocnice_main_frame.configure(background="#282828")

        self.nazev_nemocnice_frame = tk.Frame(self.insert_nemocnice_main_frame)
        self.nazev_nemocnice_frame.grid(row=0, column=0, pady=5, padx=5,sticky= "ew")
        self.nazev_nemocnice_frame.configure(background="#282828")

        self.nazev_nemocnice_label = ttk.Label(self.nazev_nemocnice_frame, text="nazev nemocnice:")
        self.nazev_nemocnice_label.grid(row=0, column=0, padx=5, pady=5,sticky= "w")
        self.nazev_nemocnice_label.configure(background="#282828", foreground="lightgray")

        self.nazev_nemocnice_entry = ttk.Entry(self.nazev_nemocnice_frame)
        self.nazev_nemocnice_entry.grid(row=0, column=1, padx=5, pady=5)

        self.ulice_nemocnice_frame = tk.Frame(self.insert_nemocnice_main_frame)
        self.ulice_nemocnice_frame.grid(row=1, column=0, pady=5, padx=5,sticky= "ew")
        self.ulice_nemocnice_frame.configure(background="#282828")

        self.ulice_nemocnice_label = ttk.Label(self.ulice_nemocnice_frame, text="ulice nemocnice:")
        self.ulice_nemocnice_label.grid(row=1, column=0, padx=5, pady=5,sticky= "w")
        self.ulice_nemocnice_label.configure(background="#282828", foreground="lightgray")

        self.ulice_nemocnice_entry = ttk.Entry(self.ulice_nemocnice_frame)
        self.ulice_nemocnice_entry.grid(row=1, column=1, padx=5, pady=5)

        self.mesto_nemocnice_frame = tk.Frame(self.insert_nemocnice_main_frame)
        self.mesto_nemocnice_frame.grid(row=2, column=0, pady=5, padx=5,sticky= "ew")
        self.mesto_nemocnice_frame.configure(background="#282828")

        self.mesto_nemocnice_label = ttk.Label(self.mesto_nemocnice_frame, text="mesto nemocnice:")
        self.mesto_nemocnice_label.grid(row=2, column=0, padx=5, pady=5,sticky= "w")
        self.mesto_nemocnice_label.configure(background="#282828", foreground="lightgray")

        self.mesto_nemocnice_entry = ttk.Entry(self.mesto_nemocnice_frame)
        self.mesto_nemocnice_entry.grid(row=2, column=1, padx=5, pady=5)

        self.cislo_popisne_nemocnice_frame = tk.Frame(self.insert_nemocnice_main_frame)
        self.cislo_popisne_nemocnice_frame.grid(row=3, column=0, pady=5, padx=5,sticky= "ew")
        self.cislo_popisne_nemocnice_frame.configure(background="#282828")

        self.cislo_popisne_nemocnice_label = ttk.Label(self.cislo_popisne_nemocnice_frame, text="cislo popisne nemocnice:")
        self.cislo_popisne_nemocnice_label.grid(row=3, column=0, padx=5, pady=5,sticky= "w")
        self.cislo_popisne_nemocnice_label.configure(background="#282828", foreground="lightgray")

        self.cislo_popisne_nemocnice_entry = ttk.Entry(self.cislo_popisne_nemocnice_frame)
        self.cislo_popisne_nemocnice_entry.grid(row=3, column=1, padx=5, pady=5)

        self.psc_nemocnice_frame = tk.Frame(self.insert_nemocnice_main_frame)
        self.psc_nemocnice_frame.grid(row=4, column=0, pady=5, padx=5,sticky= "ew")
        self.psc_nemocnice_frame.configure(background="#282828")

        self.psc_nemocnice_label = ttk.Label(self.psc_nemocnice_frame, text="psc nemocnice:")
        self.psc_nemocnice_label.grid(row=4, column=0, padx=5, pady=5,sticky= "w")
        self.psc_nemocnice_label.configure(background="#282828", foreground="lightgray")

        self.psc_nemocnice_entry = ttk.Entry(self.psc_nemocnice_frame)
        self.psc_nemocnice_entry.grid(row=4, column=1, padx=5, pady=5)

        self.id_kafeterie_frame = tk.Frame(self.insert_nemocnice_main_frame)
        self.id_kafeterie_frame.grid(row=5, column=0, pady=5, padx=5,sticky= "ew")
        self.id_kafeterie_frame.configure(background="#282828")

        self.id_kafeterie_label = ttk.Label(self.id_kafeterie_frame, text="id kafeterie:")
        self.id_kafeterie_label.grid(row=5, column=0, padx=5, pady=5,sticky= "w")
        self.id_kafeterie_label.configure(background="#282828", foreground="lightgray")

        self.id_kafeterie_entry = ttk.Entry(self.id_kafeterie_frame)
        self.id_kafeterie_entry.grid(row=5, column=1, padx=5, pady=5)

        self.odeslat_button = ttk.Button(self.insert_nemocnice, text="Odeslat", command=self.i_nemocnice)
        self.odeslat_button.grid(row=6, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.insert_nemocnice, text="Help", command=self.i_informace_nemocnice)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def update_nemocnice_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro upravení záznamu v tabulce Nemocnice
        :return:nevrací nic
        """
        self.update_nemocnice = ThemedTk()
        self.update_nemocnice.title("update_nemocnice")
        self.update_nemocnice.geometry("360x210")
        self.update_nemocnice.configure(background="#282828")
        style = ttk.Style(self.update_nemocnice)
        style.theme_use("equilux")

        self.atribut = ttk.Label(self.update_nemocnice, text="atribut který chcete upravit v tabulce nemocnice:")
        self.atribut.grid(row=0, column=0, padx=1, pady=2)
        self.atribut.configure(background="#282828", foreground="lightgray")

        self.atribut = ["nazev_nemocnice", "ulice_nemocnice", "mesto_nemocnice", "cislo_popisne_nemocnice", "psc_nemocnice", "id_kafeterie"]
        self.atribut_variable = tk.StringVar(self.update_nemocnice)
        self.atribut_variable.set(self.atribut[0])
        self.dropdown = ttk.OptionMenu(self.update_nemocnice, self.atribut_variable, *self.atribut)
        self.dropdown.grid(row=1, column=0, padx=1, pady=2)

        self.uprava_atributu = ttk.Label(self.update_nemocnice, text="na co chcete daný atribut opravit:")
        self.uprava_atributu.grid(row=2, column=0, padx=1, pady=2)
        self.uprava_atributu.configure(background="#282828", foreground="lightgray")

        self.uprava_atributu_entry = ttk.Entry(self.update_nemocnice)
        self.uprava_atributu_entry.grid(row=3, column=0, padx=1, pady=2)

        self.nazev_nemocnice = ttk.Label(self.update_nemocnice,text="nazev nemocnice u které chcete atribut upravit:")
        self.nazev_nemocnice.grid(row=4, column=0, padx=1, pady=2)
        self.nazev_nemocnice.configure(background="#282828", foreground="lightgray")

        self.nazev_nemocnice_entry = ttk.Entry(self.update_nemocnice)
        self.nazev_nemocnice_entry.grid(row=5, column=0, padx=1, pady=2)

        self.login_button = ttk.Button(self.update_nemocnice, text="Odeslat", command=self.u_nemocnice)
        self.login_button.grid(row=6, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.update_nemocnice, text="Help", command=self.u_informace_nemocnice)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def delete_nemocnice_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vymazání záznamu z tabulky Nemocnice
        :return:nevrací nic
        """
        self.delete_nemocnice = ThemedTk()
        self.delete_nemocnice.title("delete nemocnice")
        self.delete_nemocnice.configure(background="#282828")
        style = ttk.Style(self.delete_nemocnice)
        style.theme_use("equilux")

        self.nazev_nemocnice = ttk.Label(self.delete_nemocnice, text="zadejte nazev nemocnice kterou chcete smazat:")
        self.nazev_nemocnice.grid(row=0, column=0, padx=1, pady=2)
        self.nazev_nemocnice.configure(background="#282828", foreground="lightgray")

        self.nazev_nemocnice_entry = ttk.Entry(self.delete_nemocnice)
        self.nazev_nemocnice_entry.grid(row=1, column=0, padx=1, pady=2)

        self.odeslat_button = ttk.Button(self.delete_nemocnice, text="Odeslat", command=self.d_nemocnice)
        self.odeslat_button.grid(row=2, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.delete_nemocnice, text="Help", command=self.d_informace_nemocnice)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def zavri_insert_nemocnice(self):
        """
        tato metoda zavře okno pro insert Nemocnice
        :return:nevrací nic
        """
        self.insert_nemocnice.destroy()

    def zavri_update_nemocnice(self):
        """
        tato metoda zavře okno pro update Nemocnice
        :return:nevrací nic
        """
        self.update_nemocnice.destroy()

    def zavri_delete_nemocnice(self):
        """
        tato metoda zavře okno pro delete Nemocnice
        :return:nevrací nic
        """
        self.delete_nemocnice.destroy()

    def i_informace_nemocnice(self):
        messagebox.showinfo("Info","Pro úspěšný insert vyplňte správně všechny kolonky")

    def u_informace_nemocnice(self):
        messagebox.showinfo("Info","Pro úspěšný update zvolte řádek, který chcete změnit a poté vyplňte správně kolonky")

    def d_informace_nemocnice(self):
        messagebox.showinfo("Info","Pro úspěšný delete vyplňte správně název")

    def i_nemocnice(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro insert Nemocnice ošetří je regurelníma výrazama a poté je
        vloží do insert statementu pokud se insert provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        pokud uživatel zadá určitý atribut který musí být pro každý záznam unikátní tak na neho vyskočí okénko že musí
        být daný atribut unikátní
        :return: nevrací nic
        """
        i_nazev_nemocnice = self.nazev_nemocnice_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_nazev_nemocnice):
            messagebox.showerror("chyba", "nemocnice může obsahovat pouze písmena a mezery")
            raise ValueError('nemocnice musí obsahovat pouze písmena a mezery')
        i_ulice_nemocnice = self.ulice_nemocnice_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_ulice_nemocnice):
            messagebox.showerror("chyba", "ulice může obsahovat pouze písmena a mezery")
            raise ValueError('ulice musí obsahovat pouze písmena a mezery')
        i_mesto_nemocnice = self.mesto_nemocnice_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', i_mesto_nemocnice):
            messagebox.showerror("chyba", "mesto může obsahovat pouze písmena a mezery")
            raise ValueError('mesto musí obsahovat pouze písmena a mezery')
        i_cislo_popisne_nemocnice = int(self.cislo_popisne_nemocnice_entry.get())
        i_psc_nemocnice = int(self.psc_nemocnice_entry.get())
        i_id_kafeterie = int(self.id_kafeterie_entry.get())
        insert_statement = f"insert into nemocnice(nazev_nemocnice, ulice_nemocnice, mesto_nemocnice, cislo_popisne_nemocnice, psc_nemocnice,id_kafeterie) values(%s,%s,%s,%s,%s,%s)"
        values = (i_nazev_nemocnice, i_ulice_nemocnice, i_mesto_nemocnice, i_cislo_popisne_nemocnice, i_psc_nemocnice,i_id_kafeterie)

        self.cursor.execute(insert_statement, values)
        self.connection.commit()
        messagebox.showinfo("Insert", "Přidali jste do tabulky nemocnice")
        self.zavri_insert_nemocnice()


    def u_nemocnice(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro update Nemocnice ošetří je regurelníma výrazama a poté je
        vloží do update statementu pokud se update provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        a okno se zavře
        :return: nevraci nic
        """
        u_atribut = self.atribut_variable.get()
        u_uprava_atributu = self.uprava_atributu_entry.get()
        u_nazev_nemocnice = self.nazev_nemocnice_entry.get()

        if u_atribut == "nazev_nemocnice":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "nemocnice může obsahovat pouze písmena a mezery")
                raise ValueError('nemocnice musí obsahovat pouze písmena a mezery')
        elif u_atribut == "ulice_nemocnice":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "ulice může obsahovat pouze písmena a mezery")
                raise ValueError('ulice musí obsahovat pouze písmena a mezery')
        elif u_atribut == "mesto_nemocnice":
            if not re.match(r'^[a-zA-Z ]+$', u_uprava_atributu):
                messagebox.showerror("chyba", "mesto může obsahovat pouze písmena a mezery")
                raise ValueError('mesto musí obsahovat pouze písmena a mezery')

        update_statement = f"update nemocnice set {u_atribut} = '{u_uprava_atributu}' where nazev_nemocnice = '{u_nazev_nemocnice}'"
        self.cursor.execute(update_statement)
        self.connection.commit()
        messagebox.showinfo("Update", "Upravili jste tabulku nemocnice")
        self.zavri_update_nemocnice()

    def d_nemocnice(self):
        """
        Tato tabulka vezme nazev nemocnice z formuláře pro delete z tabulky Nemocnice zkontroluje ho a dosadí ho do
        delete statementu a delete provede
        :return: nevraci nic
        """
        d_nazev_nemocnice = self.nazev_nemocnice_entry.get()
        if not re.match(r'^[a-zA-Z ]+$', d_nazev_nemocnice):
            messagebox.showerror("chyba", "nemocnice může obsahovat pouze písmena a mezery")
            raise ValueError('nemocnice musí obsahovat pouze písmena a mezery')

        delete_statement = f"delete from nemocnice where nazev_nemocnice = '{d_nazev_nemocnice}'"
        self.cursor.execute(delete_statement)
        self.connection.commit()
        messagebox.showinfo("Delete", "Vymazali jste z tabulky nemocnice")
        self.zavri_delete_nemocnice()
