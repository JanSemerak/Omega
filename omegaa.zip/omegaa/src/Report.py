import tkinter as tk
from ttkthemes import ThemedTk
from tkinter import ttk
from fpdf import FPDF
import datetime
from prettytable import PrettyTable
from DatabaseConnection import DatabaseConnection


class Report(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

    def souhrny_report(self):
        """
        vytvoří okno pro vytvoření souhrného reportu
        :return: nevraci nic
        """
        souhrny_report_okno = ThemedTk()
        souhrny_report_okno.title("Souhrny_report")
        souhrny_report_okno.geometry("300x350")
        souhrny_report_okno.configure(background="#282828")
        souhrny_report_okno.configure(background="#282828")
        style = ttk.Style(souhrny_report_okno)
        style.theme_use("equilux")

        self.frame = tk.Frame(souhrny_report_okno)
        self.frame.grid(row=1, column=0, padx=0, pady=5)
        self.frame.configure(background="#282828")

        self.souhrny_report = ttk.Label(souhrny_report_okno, text="souhrny report")
        self.souhrny_report.grid(row=0, pady=15)
        self.souhrny_report.configure(background="#282828", foreground="white", font=("Helvetica", 20, "bold"))

        self.jmeno_vystavytele = ttk.Label(self.frame, text="Jmeno vystavitele: ")
        self.jmeno_vystavytele.grid(row=1, column=0, padx=5, pady=5)
        self.jmeno_vystavytele.configure(background="#282828", foreground="white")

        self.jmeno_vystavytele_entry = ttk.Entry(self.frame)
        self.jmeno_vystavytele_entry.grid(row=1, column=1)
        self.jmeno_vystavytele_entry.configure(background="#282828", foreground="white")

        self.popis_reportu_frame = tk.Frame(souhrny_report_okno)
        self.popis_reportu_frame.grid(row=2, column=0, pady=5)
        self.popis_reportu_frame.configure(background="#282828")

        self.popis_reportu = ttk.Label(self.popis_reportu_frame, text="Popis reportu: ")
        self.popis_reportu.grid(row=1, column=0, padx=5, pady=5)
        self.popis_reportu.configure(background="#282828", foreground="white")

        self.popis_reportu_entry = ttk.Entry(self.popis_reportu_frame)
        self.popis_reportu_entry.grid(row=1, column=1)
        self.popis_reportu_entry.configure(background="#282828", foreground="white")

        self.zkontroloval_frame = tk.Frame(souhrny_report_okno)
        self.zkontroloval_frame.grid(row=4, column=0, pady=5)
        self.zkontroloval_frame.configure(background="#282828")

        self.zkontroloval = ttk.Label(self.zkontroloval_frame, text="Zkontroloval: ")
        self.zkontroloval.grid(row=1, column=0, padx=5, pady=5)
        self.zkontroloval.configure(background="#282828", foreground="white")

        self.zkontroloval_entry = ttk.Entry(self.zkontroloval_frame)
        self.zkontroloval_entry.grid(row=1, column=1)
        self.zkontroloval_entry.configure(background="#282828", foreground="white")

        self.komentar_frame = tk.Frame(souhrny_report_okno)
        self.komentar_frame.grid(row=5, column=0, pady=5)
        self.komentar_frame.configure(background="#282828")

        self.komentar = ttk.Label(self.komentar_frame, text="Komentář: ")
        self.komentar.grid(row=1, column=0, padx=5, pady=5)
        self.komentar.configure(background="#282828", foreground="white")

        self.komentar_entry = ttk.Entry(self.komentar_frame)
        self.komentar_entry.grid(row=1, column=1)
        self.komentar_entry.configure(background="#282828", foreground="white")

        self.schvaleni_frame = tk.Frame(souhrny_report_okno)
        self.schvaleni_frame.grid(row=6, pady=5)
        self.schvaleni_frame.configure(background="#282828")

        self.schvaleni = ttk.Label(self.schvaleni_frame, text="Schváleno: ")
        self.schvaleni.grid(row=1,column=0, padx=5, pady=5)
        self.schvaleni.configure(background="#282828", foreground="white")

        self.ano = tk.IntVar()
        self.ano_checkbox = ttk.Checkbutton(self.schvaleni_frame, variable=self.ano, onvalue=1, offvalue=0, command=self.schvaleni_vysledek)
        self.ano_checkbox.grid(row=1, column=1)

        self.podpis_frame = tk.Frame(souhrny_report_okno)
        self.podpis_frame.grid(row=7, pady=5)
        self.podpis_frame.configure(background="#282828")

        self.podpis = ttk.Label(self.podpis_frame, text="Podpis: ")
        self.podpis.grid(row=1, column=0, padx=5, pady=5)
        self.podpis.configure(background="#282828", foreground="white")

        self.podpis_entry = ttk.Entry(self.podpis_frame)
        self.podpis_entry.grid(row=1, column=1)
        self.podpis_entry.configure(background="#282828")

        self.button = ttk.Button(souhrny_report_okno, text="Vygenerovat", command=self.get_text)
        self.button.grid(row=8, pady=5)

        souhrny_report_okno.mainloop()

    def schvaleni_vysledek(self):
        ano_var = self.ano.get()

        if ano_var == 0:
            return "ano"
        elif ano_var == 1:
            return "ne"

    def get_text(self):
        """
        vytvoří objekt trídy FPDF získá hodnoty z políček z formuláře přidá do pdf souboru stránku nastaví font poté vkládá
        do pdf souboru získané hodnoty z políček a nakonec pdf soubor vytvoří
        :return:
        """
        pdf = FPDF()
        text = self.jmeno_vystavytele_entry.get()
        datum_reportu = datetime.datetime.now()
        table2 = PrettyTable()
        table2.field_names = ["Lekar", "Pacient", "Datum"]
        self.cursor.execute(
            f"SELECT lekar.prijmeni_lekar, pacient.prijmeni_pacient, navsteva.datum_navsteva FROM navsteva JOIN lekar ON navsteva.id_lekar = lekar.id_lekar JOIN pacient ON navsteva.id_pacient = pacient.id_pacient;")
        result2 = self.cursor.fetchall()
        vysledek = []
        for row in result2:
            vysledek.append(row)

        zkontroloval = self.zkontroloval_entry.get()
        popis_reportu = self.popis_reportu_entry.get()
        komentar = self.komentar_entry.get()
        podpis = self.podpis_entry.get()

        pdf.add_page()

        pdf.set_font("Arial", "B", 16)

        pdf.cell(200, 10, txt="Prehled navstev", ln=1, align='C')
        pdf.cell(200, 10, txt=f"Jmeno lekare, ktery report vystavil: {text}", ln=2, align='L')
        pdf.cell(200, 10, txt=f"Datum vytvoreni reportu: {datum_reportu}", ln=3, align='L')
        pdf.cell(200, 10, txt=f"Popis reportu: {popis_reportu}", ln=4, align='L')
        pdf.cell(200, 10, txt="Navstevy", ln=5, align='L')
        pdf.cell(200, 10, txt=str(table2.field_names), ln=6, align='C')
        pdf.cell(200, 10, txt=str(vysledek[0]), ln=7, align='C')
        pdf.cell(200, 10, txt=str(vysledek[1]), ln=8, align='C')
        pdf.cell(200, 10, txt=f"Zkontroloval: {zkontroloval}", ln=10, align='L')
        pdf.cell(200, 10, txt=f"Komentar: {komentar}", ln=11, align='L')
        pdf.cell(200, 10, txt=f"Schvaleno:" + self.schvaleni_vysledek())
        pdf.cell(200, 10, txt=f"Podpis: {podpis}", ln=12, align='L')
        pdf.output("file.pdf")