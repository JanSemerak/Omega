import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
from tkinter import messagebox
import mysql.connector
import re

from DatabaseConnection import DatabaseConnection


class Registrace(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

    def registrace_button(self):
        self.registrace = ThemedTk()
        self.registrace.title("Registrace")
        self.registrace.configure(background="#D3D3D3")
        self.registrace.configure(background="#D3D3D3")

        self.registrace_label = tk.Label(self.registrace, text="Registrace", font=("Helvetica", 32, "bold"))
        self.registrace_label.grid(row=0, column=0, pady=10)
        self.registrace_label.configure(background="#D3D3D3")

        self.registrace_main_frame = tk.Frame(self.registrace)
        self.registrace_main_frame.grid(row=1, column=0, pady=50, padx=100, sticky="nsew")
        self.registrace_main_frame.configure(background="#D3D3D3")

        self.frame_prihlasovaci_jmeno = tk.Frame(self.registrace_main_frame, padx=10, pady=5)
        self.frame_prihlasovaci_jmeno.grid(row=0, column=0, sticky="ew")
        self.frame_prihlasovaci_jmeno.configure(background="#D3D3D3")

        self.prihlasovaci_jmeno_label = ttk.Label(self.frame_prihlasovaci_jmeno, text="Přihlašovací jméno:")
        self.prihlasovaci_jmeno_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.prihlasovaci_jmeno_label.configure(background="#D3D3D3", foreground="black", font=(None, 15, "bold"))

        self.prihlasovaci_jmeno_entry = ttk.Entry(self.frame_prihlasovaci_jmeno)
        self.prihlasovaci_jmeno_entry.grid(row=0, column=1, padx=5, pady=5, ipadx=20)

        self.frame_email = tk.Frame(self.registrace_main_frame, padx=10, pady=5)
        self.frame_email.grid(row=1, column=0, sticky="ew")
        self.frame_email.configure(background="#D3D3D3")

        self.email_label = ttk.Label(self.frame_email, text="Email:")
        self.email_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.email_label.configure(background="#D3D3D3", foreground="black", font=(None, 15, "bold"))

        self.email_entry = ttk.Entry(self.frame_email)
        self.email_entry.grid(row=0, column=1, padx=5, pady=5, ipadx=20)

        self.frame_telefon = tk.Frame(self.registrace_main_frame, padx=10, pady=5)
        self.frame_telefon.grid(row=2, column=0, sticky="ew")
        self.frame_telefon.configure(background="#D3D3D3")

        self.telefon_label = ttk.Label(self.frame_telefon, text="Telefon:")
        self.telefon_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.telefon_label.configure(background="#D3D3D3", foreground="black", font=(None, 15 ,"bold"))

        self.telefon_entry = ttk.Entry(self.frame_telefon)
        self.telefon_entry.grid(row=0, column=1, padx=5, pady=5, ipadx=20)

        self.frame_heslo = tk.Frame(self.registrace_main_frame, padx=10, pady=5)
        self.frame_heslo.grid(row=3, column=0, sticky="ew")
        self.frame_heslo.configure(background="#D3D3D3")

        self.heslo_label = ttk.Label(self.frame_heslo, text="Heslo:")
        self.heslo_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.heslo_label.configure(background="#D3D3D3", foreground="black", font=(None, 15 ,"bold"))

        self.heslo_entry = ttk.Entry(self.frame_heslo, show="*")
        self.heslo_entry.grid(row=0, column=1, padx=5, pady=5, ipadx=20)

        self.frame_potvrzeni_hesla = tk.Frame(self.registrace_main_frame, padx=10, pady=5)
        self.frame_potvrzeni_hesla.grid(row=4, column=0, sticky="ew")
        self.frame_potvrzeni_hesla.configure(background="#D3D3D3")

        self.potvrzeni_hesla_label = ttk.Label(self.frame_potvrzeni_hesla, text="Potvrzení hesla:")
        self.potvrzeni_hesla_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.potvrzeni_hesla_label.configure(background="#D3D3D3", foreground="black", font=(None, 15, "bold"))

        self.potvrzeni_hesla_entry = ttk.Entry(self.frame_potvrzeni_hesla, show="*")
        self.potvrzeni_hesla_entry.grid(row=0, column=1, padx=5, pady=5, ipadx=20)

        self.odeslat_button = ttk.Button(self.registrace_main_frame, text="Odeslat", command=self.pridani_uzivatele)
        self.odeslat_button.grid(row=5, column=0, pady=10, padx=10, sticky="ew")



        self.registrace.grid_rowconfigure(1, weight=1)
        self.registrace.grid_columnconfigure(0, weight=1)

    def zapomenute_heslo(self):
        self.zapomenute_heslo = ThemedTk()
        self.zapomenute_heslo.title("Změna hesla")
        self.zapomenute_heslo.configure(background="#D3D3D3")

        self.registrace_label = tk.Label(self.zapomenute_heslo, text="Změna hesla", font=("Helvetica", 32, "bold"))
        self.registrace_label.grid(row=0, column=0, pady=10)
        self.registrace_label.configure(background="#D3D3D3")

        self.registrace_main_frame = tk.Frame(self.zapomenute_heslo)
        self.registrace_main_frame.grid(row=1, column=0, pady=50, padx=100, sticky="nsew")
        self.registrace_main_frame.configure(background="#D3D3D3")

        self.frame_prihlasovaci_jmeno = tk.Frame(self.registrace_main_frame, padx=10, pady=5)
        self.frame_prihlasovaci_jmeno.grid(row=0, column=0, sticky="ew")
        self.frame_prihlasovaci_jmeno.configure(background="#D3D3D3")

        self.prihlasovaci_jmeno_label = ttk.Label(self.frame_prihlasovaci_jmeno, text="Přihlašovací jméno:")
        self.prihlasovaci_jmeno_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.prihlasovaci_jmeno_label.configure(background="#D3D3D3", foreground="black", font=(None, 15, "bold"))

        self.prihlasovaci_jmeno_entry = ttk.Entry(self.frame_prihlasovaci_jmeno)
        self.prihlasovaci_jmeno_entry.grid(row=0, column=1, padx=5, pady=5, ipadx=20)

        self.nove_heslo_frame = tk.Frame(self.registrace_main_frame, padx=10, pady=5)
        self.nove_heslo_frame.grid(row=1, column=0, sticky="ew")
        self.nove_heslo_frame.configure(background="#D3D3D3")

        self.nove_heslo_label = ttk.Label(self.nove_heslo_frame, text="Nové heslo:")
        self.nove_heslo_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.nove_heslo_label.configure(background="#D3D3D3", foreground="black", font=(None, 15,"bold"))

        self.nove_heslo_entry = ttk.Entry(self.nove_heslo_frame, show="*")
        self.nove_heslo_entry.grid(row=0, column=1, padx=5, pady=5, ipadx=20)

        self.nove_heslo_potvrzeni_frame = tk.Frame(self.registrace_main_frame, padx=10, pady=5)
        self.nove_heslo_potvrzeni_frame.grid(row=2, column=0, sticky="ew")
        self.nove_heslo_potvrzeni_frame.configure(background="#D3D3D3")

        self.nove_heslo_potvrzeni_label = ttk.Label(self.nove_heslo_potvrzeni_frame, text="Potvrzení nového hesla:")
        self.nove_heslo_potvrzeni_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.nove_heslo_potvrzeni_label.configure(background="#D3D3D3", foreground="black", font=(None, 15,"bold"))

        self.nove_heslo_potvrzeni_entry = ttk.Entry(self.nove_heslo_potvrzeni_frame, show="*")
        self.nove_heslo_potvrzeni_entry.grid(row=0, column=1, padx=5, pady=5, ipadx=20)

        self.odeslat_button = ttk.Button(self.registrace_main_frame, text="Odeslat", command=self.zmena_hesla)
        self.odeslat_button.grid(row=3, column=0, pady=10, padx=10, sticky="ew")


        self.zapomenute_heslo.grid_rowconfigure(1, weight=1)
        self.zapomenute_heslo.grid_columnconfigure(0, weight=1)

    def zavrit_okno_registrace(self):
        """
        tato metoda zavre okno pro registraci
        :return:
        """
        self.registrace.destroy()

    def zavrit_okno_zmena_hesla(self):
        """
        tato metoda zavre okno pro zmenu hesla
        :return:
        """
        self.zapomenute_heslo.destroy()

    def pridani_uzivatele(self):
        """
        metoda vezme hodnoty z políček a zkontroluje je pomocí regurálních výrazů a pokud se heslo schoduje s potvrzením
        hesla tak se hodnoty dosadí do insert statementu a pokud ne vyskočí error okno ze se hesla neshodují a insert se neprovede
        :return:nevrací nic
        """
        pridani_jmeno = self.prihlasovaci_jmeno_entry.get()
        if not re.match(r"^[A-Za-z0-9]+$", pridani_jmeno):
            messagebox.showerror("chyba", "Prihlasovaci jmeno muze obsahovat pouze pismena a cisla")
            raise ValueError('špatně zadané přihlašovací jméno')
        pridani_email = self.email_entry.get()
        if not re.match(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", pridani_email):
            messagebox.showerror("chyba", "Email musí obsahovat @ a například .com")
            raise ValueError('špatně zadaný email')
        pridani_telefon = self.telefon_entry.get()
        if not re.match(r'^\d{9}$', pridani_telefon):
            messagebox.showerror("chyba", "Telefon Musí obsahovat přesně 9 číslic")
            raise ValueError('Telefon musí obsahovat právě 9 číslic')
        pridani_heslo = self.heslo_entry.get()
        if not re.match(r"^[A-Za-z0-9]+$", pridani_heslo):
            messagebox.showerror("chyba", "Heslo muze obsahovat pouze pismena a cisla")
            raise ValueError('špatně zadané heslo')
        pridani_potvrzeni_heslo = self.potvrzeni_hesla_entry.get()
        if not re.match(r"^[A-Za-z0-9]+$", pridani_potvrzeni_heslo):
            messagebox.showerror("chyba", "Potvrzeni hesla muze obsahovat pouze pismena a cisla")
            raise ValueError('špatně zadané heslo')

        if pridani_heslo == pridani_potvrzeni_heslo:
            try:
                insert_statement = f"insert into prihlaseni(jmeno, email, telefon, heslo)values(%s,%s,%s,%s)"
                values = (pridani_jmeno, pridani_email, pridani_telefon, pridani_heslo)
                self.cursor.execute(insert_statement, values)
                self.connection.commit()
                messagebox.showinfo("registrace", "Vaše registrace proběhla úspěšně")
                self.zavrit_okno_registrace()
            except mysql.connector.errors.IntegrityError:
                messagebox.showerror("Chyba","Uživatel musí mít všechny atributy unikátní")
        elif pridani_heslo != pridani_potvrzeni_heslo:
            messagebox.showerror("Chyba", 'heslo a potvrzení hesla se neshodují')

    def zmena_hesla(self):
        """
        metoda vezme hodnoty z políček a zkontroluje je pomocí regurálních výrazů a pokud se heslo schoduje s potvrzením
        hesla tak se hodnoty dosadí do update statementu a pokud ne vyskočí error okno ze se hesla neshodují a update se
        neprovede
        :return:nevrací nic
        """
        pr_jmeno = self.prihlasovaci_jmeno_entry.get()
        if not re.match(r"^[A-Za-z0-9]+$", pr_jmeno):
            messagebox.showerror("chyba", "Prihlasovaci jmeno muze obsahovat pouze pismena a cisla")
            raise ValueError('špatně zadané jméno')
        nove_heslo = self.nove_heslo_entry.get()
        if not re.match(r"^[A-Za-z0-9]+$", nove_heslo):
            messagebox.showerror("chyba", "Heslo muze obsahovat pouze pismena a cisla")
            raise ValueError('špatně zadané heslo')
        nove_heslo_potvzeni = self.nove_heslo_potvrzeni_entry.get()
        if not re.match(r"^[A-Za-z0-9]+$", nove_heslo_potvzeni):
            messagebox.showerror("chyba", "Potvrzeni hesla muze obsahovat pouze pismena a cisla")
            raise ValueError('špatně zadané heslo')

        if nove_heslo == nove_heslo_potvzeni:
            update_statement = f"update prihlaseni set heslo = '{nove_heslo}' where jmeno = '{pr_jmeno}'"
            self.cursor.execute(update_statement)
            self.connection.commit()
            messagebox.showinfo("Změna", "Vaše heslo bylo úspěsně změněno")
            self.zavrit_okno_zmena_hesla()
        elif nove_heslo != nove_heslo_potvzeni:
            messagebox.showerror("Chyba", "nové heslo a potvrzení nového hesla se neshodují")