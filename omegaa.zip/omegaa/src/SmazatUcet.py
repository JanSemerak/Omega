import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
from tkinter import messagebox
import re

from DatabaseConnection import DatabaseConnection

class SmazatUcet(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

    def smazat_button(self):
        self.smazat = ThemedTk()
        self.smazat.title("smazat")
        self.smazat.configure(background="#D3D3D3")

        self.smazat_label = tk.Label(self.smazat, text="smazat", font=("Helvetica", 32, "bold"))
        self.smazat_label.grid(row=0, column=0, pady=10)
        self.smazat_label.configure(background="#D3D3D3")

        self.smazat_main_frame = tk.Frame(self.smazat)
        self.smazat_main_frame.grid(row=1, column=0, pady=50, padx=100, sticky="nsew")
        self.smazat_main_frame.configure(background="#D3D3D3")

        self.frame_prihlasovaci_jmeno = tk.Frame(self.smazat_main_frame, padx=10, pady=5)
        self.frame_prihlasovaci_jmeno.grid(row=0, column=0, sticky="ew")
        self.frame_prihlasovaci_jmeno.configure(background="#D3D3D3")

        self.prihlasovaci_jmeno_label = ttk.Label(self.frame_prihlasovaci_jmeno, text="Přihlašovací jméno:")
        self.prihlasovaci_jmeno_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.prihlasovaci_jmeno_label.configure(background="#D3D3D3", foreground="black", font=(None, 15, "bold"))

        self.prihlasovaci_jmeno_entry = ttk.Entry(self.frame_prihlasovaci_jmeno)
        self.prihlasovaci_jmeno_entry.grid(row=0, column=1, padx=5, pady=5, ipadx=20)

        self.frame_heslo = tk.Frame(self.smazat_main_frame, padx=10, pady=5)
        self.frame_heslo.grid(row=3, column=0, sticky="ew")
        self.frame_heslo.configure(background="#D3D3D3")

        self.heslo_label = ttk.Label(self.frame_heslo, text="Heslo:")
        self.heslo_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.heslo_label.configure(background="#D3D3D3", foreground="black", font=(None, 15 ,"bold"))

        self.heslo_entry = ttk.Entry(self.frame_heslo, show="*")
        self.heslo_entry.grid(row=0, column=1, padx=5, pady=5, ipadx=20)
        self.odeslat_button = ttk.Button(self.smazat_main_frame, text="Odeslat", command=self.smazani_uzivatele)
        self.odeslat_button.grid(row=5, column=0, pady=10, padx=10, sticky="ew")

    def zavrit_okno_smazani(self):
        self.smazat.destroy()

    def smazani_uzivatele(self):
        """
            Metoda pro smazání uživatele z databáze.
            Metoda získává přihlašovací jméno a heslo z GUI vstupních polí.
            Ověřuje, zda jsou přihlašovací údaje ve správném formátu (pouze písmena a čísla).
            V případě neplatného formátu přihlašovacích údajů vyvolává ValueError.
            Pokud jsou údaje ve správném formátu, provede smazání uživatele z databáze.
            Po smazání záznamu se změny zapsají do databáze
            Raises:
                ValueError: Pokud je přihlašovací jméno nebo heslo ve špatném formátu.

            """
        smazani_jmeno = self.prihlasovaci_jmeno_entry.get()
        if not re.match(r"^[A-Za-z0-9]+$", smazani_jmeno):
            messagebox.showerror("chyba", "Prihlasovaci jmeno muze obsahovat pouze pismena a cisla")
            raise ValueError('špatně zadané přihlašovací jméno')
        smazani_heslo = self.heslo_entry.get()
        if not re.match(r"^[A-Za-z0-9]+$", smazani_heslo):
            messagebox.showerror("chyba", "Heslo muze obsahovat pouze pismena a cisla")
            raise ValueError('špatně zadané heslo')

        delete_statement = f"DELETE FROM prihlaseni WHERE jmeno = '{smazani_jmeno}' and heslo = '{smazani_heslo}';"
        self.cursor.execute(delete_statement)
        self.connection.commit()
        messagebox.showinfo("Delete", "Vymazali jste z tabulky prihlaseni")
        self.zavrit_okno_smazani()
