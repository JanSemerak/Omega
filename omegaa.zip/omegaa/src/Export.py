import csv
import json
import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
from datetime import date
from tkinter import messagebox

from DatabaseConnection import DatabaseConnection


class Export(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

    def export_data(self):
        """
        Okno pro export dat
        :return: nevraci nic
        """
        self.export_dat = ThemedTk()
        self.export_dat.title("Export dat")
        self.export_dat.geometry("500x350")
        self.export_dat.configure(background="#282828")
        style = ttk.Style(self.export_dat)
        style.theme_use("equilux")

        label = ttk.Label(self.export_dat, text="Export dat")
        label.configure(background="#282828", padding=40, font=("Helvetica", 20, "bold"), foreground="white")
        label.pack()

        self.atribut = ["lekar", "nacini", "navsteva", "oddeleni", "pacient", "pojistovna", "nemocnice", "kafeterie"]
        self.atribut_variable = tk.StringVar(self.export_dat)
        self.atribut_variable.set(self.atribut[0])
        dropdown = ttk.OptionMenu(self.export_dat, self.atribut_variable, *self.atribut)
        dropdown.configure(padding=5)
        dropdown.pack(pady=12)

        self.typ_souboru = ["csv", "json"]
        self.typ_souboru_variable = tk.StringVar(self.export_dat)
        self.typ_souboru_variable.set(self.atribut[0])
        dropdown = ttk.OptionMenu(self.export_dat, self.typ_souboru_variable, *self.typ_souboru)
        dropdown.configure(padding=5)
        dropdown.pack(pady=12)

        button = ttk.Button(self.export_dat, text="Export", command=self.export_table)
        button.pack(pady=12)
        zpet_button = ttk.Button(self.export_dat, text="zpet", command=self.zpet_do_menu)
        zpet_button.pack()
        self.export_dat.mainloop()

    select_dict = {"lekar": "select * from lekar;",
                   "nacini": "select * from nacini",
                   "navsteva": "select * from navsteva",
                   "oddeleni": "select * from oddeleni",
                   "pacient": "select * from pacient",
                   "pojistovna": "select * from pojistovna",
                   "nemocnice": "select * from nemocnice",
                   "kafeterie": "select * from kafeterie"
                   }

    def get_dict(self,vybrana_tabulka):
        """
           Vrací SELECT statement pro zvolenou tabulku.
         """
        return self.select_dict[vybrana_tabulka]

    def export_table(self):
        """
            Exportuje data vybrané tabulky do souboru ve formátu CSV nebo JSON.

            Metoda nejprve získává hodnoty vybrané tabulky a typu souboru z rozbalovacích
            menu. Pokud je vybraný typ souboru CSV, provede se dotaz na databázi pro získání
            dat ze zvolené tabulky. Tato data jsou poté zapsána do souboru s příponou .csv.
            Pokud je vybraný typ souboru JSON, stejným způsobem se získají data a názvy
            sloupců ze zvolené tabulky. Poté jsou data zpracována do formátu vhodného pro
            JSON a zapsána do souboru s příponou .json.

            :return: Nevrací žádnou hodnotu.
        """
        vybrana_tabulka = self.atribut_variable.get()
        vybrany_typ_souboru = self.typ_souboru_variable.get()
        if vybrany_typ_souboru == "csv":
            select_statement = self.get_dict(vybrana_tabulka)
            self.cursor.execute(select_statement)
            data = self.cursor.fetchall()
            print(select_statement)
            with open(f"{vybrana_tabulka}_export.csv", 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerows(data)
            messagebox.showinfo("Export", "Export proběhl úspesně")
        elif vybrany_typ_souboru == "json":
            select_statement = self.get_dict(vybrana_tabulka)
            self.cursor.execute(select_statement)
            data = self.cursor.fetchall()
            keys = [i[0] for i in self.cursor.description]

            json_data = []
            for row in data:
                row_dict = {}
                for i in range(len(keys)):
                    if isinstance(row[i], date):
                        row_dict[keys[i]] = row[i].strftime("%Y-%m-%d")
                    else:
                        row_dict[keys[i]] = str(row[i])
                json_data.append(row_dict)

            with open(f'{vybrana_tabulka}_export.json', 'w', encoding='utf-8') as outfile:
                json.dump(json_data, outfile, ensure_ascii=False)
            messagebox.showinfo("Export", "Export proběhl úspesně")
        self.export_dat.destroy()

    def zpet_do_menu(self):
        """
        Zavře okno a vrátí se do menu
        :return: nevraci nic
        """
        self.export_dat.destroy()