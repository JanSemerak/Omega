import tkinter as tk
from tkinter import ttk
from ttkthemes import ThemedTk
from tkinter import messagebox
from DatabaseConnection import DatabaseConnection


class Navsteva(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        db_connection = DatabaseConnection()
        self.connection = db_connection.get_connection()
        self.cursor = db_connection.get_cursor()

    def navsteva_button(self):
        """
        Tato metoda vytváří okno které obsahuje tabulku Navsteva a tlačítka pro insert, update a delete tlačítko
        které okno zavře a do menu
        :return: nevrací nic
        """
        self.cursor.execute("SELECT navsteva.id_navsteva, navsteva.datum_navsteva, navsteva.cena_navsteva, navsteva.id_pacient, navsteva.id_lekar, navsteva.id_nacini FROM navsteva")
        rows = self.cursor.fetchall()

        navsteva = ThemedTk()
        navsteva.title("navsteva")
        navsteva.geometry("1920x1080")
        navsteva.configure(background="#282828")
        navsteva.configure(background="#282828")
        style = ttk.Style(navsteva)
        style.theme_use("equilux")

        self.navsteva_main_frame = tk.Frame(navsteva)
        self.navsteva_main_frame.grid(row=1, column=0, padx=100, pady=200)
        self.navsteva_main_frame.configure(background="#282828")

        self.navsteva = ttk.Label(self.navsteva_main_frame, text="Tabulka navsteva")
        self.navsteva.grid(row=0)
        self.navsteva.configure(background="#282828", padding=20, font=("Helvetica", 40, "bold"), foreground="white")

        self.table_frame = tk.Frame(self.navsteva_main_frame)
        self.table_frame.grid(row=1, column=0, padx=10, pady=0)
        self.table_frame.configure(background="#282828")

        table = ttk.Treeview(self.table_frame, columns=(
           "datum_navsteva", "cena_navsteva", "id_pacient", "id_lekar", "id_nacini"))

        table.heading("#0", text="ID")
        table.heading("datum_navsteva", text="datum_navsteva")
        table.heading("cena_navsteva", text="cena_navsteva")
        table.heading("id_pacient", text="id_pacient")
        table.heading("id_lekar", text="id_lekar")
        table.heading("id_nacini", text="id_nacini")

        for row in rows:
            table.insert("", "end", text=row[0], values=(row[1], row[2], row[3], row[4], row[5]))

        table.grid(row=1, pady=5, padx=210)

        def zavri_navsteva():
            navsteva.destroy()

        self.button_frame = tk.Frame(self.navsteva_main_frame)
        self.button_frame.grid(row=2, column=0, padx=0, pady=5)
        self.button_frame.configure(background="#282828")

        self.zpet_button_frame = tk.Frame(self.navsteva_main_frame)
        self.zpet_button_frame.grid(row=3, column=0, padx=0, pady=5)
        self.zpet_button_frame.configure(background="#282828")

        insert_navsteva = ttk.Button(self.button_frame, text="insert", command=self.insert_navsteva_window)
        update_navsteva = ttk.Button(self.button_frame, text="update", command=self.update_navsteva_window)
        delete_navsteva = ttk.Button(self.button_frame, text="delete", command=self.delete_navsteva_window)
        zpet = ttk.Button(self.zpet_button_frame, text="zpet", command=zavri_navsteva)
        insert_navsteva.grid(padx=5,pady=5, row=2, column=0)
        update_navsteva.grid(padx=5,pady=5, row=2, column=1)
        delete_navsteva.grid(padx=5,pady=5, row=2, column=2)
        zpet.grid(pady=5, row=5, column=0)

    def insert_navsteva_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vložení záznamu do tabulky Navsteva
        :return:nevrací nic
        """
        self.insert_navsteva = ThemedTk()
        self.insert_navsteva.title("insert_navsteva")
        self.insert_navsteva.geometry("400x380")
        self.insert_navsteva.configure(background="#282828")
        style = ttk.Style(self.insert_navsteva)
        style.theme_use("equilux")

        self.nav = ttk.Label(self.insert_navsteva, text="Insert navsteva")
        self.nav.grid(row=0)
        self.nav.configure(background="#282828", padding=20, font=("Helvetica", 20, "bold"), foreground="white")

        self.insert_navsteva_main_frame = tk.Frame(self.insert_navsteva)
        self.insert_navsteva_main_frame.grid(row=1, column=0, padx=0, pady=5)
        self.insert_navsteva_main_frame.configure(background="#282828")

        self.datum_navsteva_frame = tk.Frame(self.insert_navsteva_main_frame)
        self.datum_navsteva_frame.grid(row=0, column=0, pady=5, padx=5, sticky= "ew")
        self.datum_navsteva_frame.configure(background="#282828")

        self.datum_navsteva_label = ttk.Label(self.datum_navsteva_frame, text="datum:")
        self.datum_navsteva_label.grid(row=0, column=0, padx=5, pady=5, sticky= "w")
        self.datum_navsteva_label.configure(background="#282828", foreground="lightgray")

        self.datum_navsteva_entry = ttk.Entry(self.datum_navsteva_frame)
        self.datum_navsteva_entry.grid(row=0, column=1, padx=5, pady=5)

        self.cena_navsteva_frame = tk.Frame(self.insert_navsteva_main_frame)
        self.cena_navsteva_frame.grid(row=1, column=0, pady=5, padx=5, sticky= "ew")
        self.cena_navsteva_frame.configure(background="#282828")

        self.cena_navsteva_label = ttk.Label(self.cena_navsteva_frame, text="cena:")
        self.cena_navsteva_label.grid(row=1, column=0, padx=5, pady=5, sticky= "w")
        self.cena_navsteva_label.configure(background="#282828", foreground="lightgray")

        self.cena_navsteva_entry = ttk.Entry(self.cena_navsteva_frame)
        self.cena_navsteva_entry.grid(row=1, column=1, padx=5, pady=5)

        self.id_pacient_frame = tk.Frame(self.insert_navsteva_main_frame)
        self.id_pacient_frame.grid(row=2, column=0, pady=5, padx=5, sticky= "ew")
        self.id_pacient_frame.configure(background="#282828")

        self.id_pacient_label = ttk.Label(self.id_pacient_frame, text="pacient:")
        self.id_pacient_label.grid(row=2, column=0, padx=5, pady=5, sticky= "w")
        self.id_pacient_label.configure(background="#282828", foreground="lightgray")

        self.id_pacient_entry = ttk.Entry(self.id_pacient_frame)
        self.id_pacient_entry.grid(row=2, column=1, padx=5, pady=5)

        self.id_lekar_frame = tk.Frame(self.insert_navsteva_main_frame)
        self.id_lekar_frame.grid(row=3, column=0, pady=5, padx=5, sticky= "ew")
        self.id_lekar_frame.configure(background="#282828")

        self.id_lekar_label = ttk.Label(self.id_lekar_frame, text="lekar:")
        self.id_lekar_label.grid(row=3, column=0, padx=5, pady=5, sticky= "w")
        self.id_lekar_label.configure(background="#282828", foreground="lightgray")

        self.id_lekar_entry = ttk.Entry(self.id_lekar_frame)
        self.id_lekar_entry.grid(row=3, column=1, padx=5, pady=5)

        self.id_nacini_frame = tk.Frame(self.insert_navsteva_main_frame)
        self.id_nacini_frame.grid(row=4, column=0, pady=5, padx=5, sticky= "ew")
        self.id_nacini_frame.configure(background="#282828")

        self.id_nacini_label = ttk.Label(self.id_nacini_frame, text="nacini:")
        self.id_nacini_label.grid(row=4, column=0, padx=5, pady=5, sticky= "w")
        self.id_nacini_label.configure(background="#282828", foreground="lightgray")

        self.id_nacini_entry = ttk.Entry(self.id_nacini_frame)
        self.id_nacini_entry.grid(row=4, column=1, padx=5, pady=5)

        self.odeslat_button = ttk.Button(self.insert_navsteva, text="Odeslat", command=self.i_navsteva)
        self.odeslat_button.grid(row=5, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.insert_navsteva, text="Help", command=self.i_informace_navsteva)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)
    def update_navsteva_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro upravení záznamu v tabulce Navsteva
        :return:nevrací nic
        """
        self.update_navsteva = ThemedTk()
        self.update_navsteva.title("update navsteva")
        self.update_navsteva.geometry("360x210")
        self.update_navsteva.configure(background="#282828")
        style = ttk.Style(self.update_navsteva)
        style.theme_use("equilux")

        self.atribut = ttk.Label(self.update_navsteva, text="atribut který chcete upravit v tabulce navsteva:")
        self.atribut.grid(row=0, column=0, padx=1, pady=2)
        self.atribut.configure(background="#282828", foreground="lightgray")

        self.atribut = ["datum_navsteva", "cena_navsteva", "id_pacient", "id_lekar", "id_nacini"]
        self.atribut_variable = tk.StringVar(self.update_navsteva)
        self.atribut_variable.set(self.atribut[0])
        self.dropdown = ttk.OptionMenu(self.update_navsteva, self.atribut_variable, *self.atribut)
        self.dropdown.grid(row=1, column=0, padx=1, pady=2)

        self.uprava_atributu = ttk.Label(self.update_navsteva, text="na co chcete daný atribut opravit:")
        self.uprava_atributu.grid(row=2, column=0, padx=1, pady=2)
        self.uprava_atributu.configure(background="#282828", foreground="lightgray")

        self.uprava_atributu_entry = ttk.Entry(self.update_navsteva)
        self.uprava_atributu_entry.grid(row=3, column=0, padx=1, pady=2)

        self.datum_navstevy = ttk.Label(self.update_navsteva,text="datum navsteva u kterého chcete atribut upravit:")
        self.datum_navstevy.grid(row=4, column=0, padx=1, pady=2)
        self.datum_navstevy.configure(background="#282828", foreground="lightgray")

        self.datum_navstevy_entry = ttk.Entry(self.update_navsteva)
        self.datum_navstevy_entry.grid(row=5, column=0, padx=1, pady=2)

        self.login_button = ttk.Button(self.update_navsteva, text="Odeslat", command=self.u_navsteva)
        self.login_button.grid(row=6, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.update_navsteva, text="Help", command=self.u_informace_navsteva)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def delete_navsteva_window(self):
        """
        Tato metoda vytvoří okno které obsahuje formulář pro vymazání záznamu z tabulky Navsteva
        :return:nevrací nic
        """
        self.delete_navsteva = ThemedTk()
        self.delete_navsteva.title("delete_navsteva")
        self.delete_navsteva.configure(background="#282828")
        style = ttk.Style(self.delete_navsteva)
        style.theme_use("equilux")

        self.datum_navstevy = ttk.Label(self.delete_navsteva, text="zadejte datum navstevy kterou chcete smazat:")
        self.datum_navstevy.grid(row=0, column=0, padx=1, pady=2)
        self.datum_navstevy.configure(background="#282828", foreground="lightgray")

        self.datum_navstevy_entry = ttk.Entry(self.delete_navsteva)
        self.datum_navstevy_entry.grid(row=1, column=0, padx=1, pady=2)

        self.odeslat_button = ttk.Button(self.delete_navsteva, text="Odeslat", command=self.d_navsteva)
        self.odeslat_button.grid(row=2, column=0, columnspan=2, padx=5, pady=5)

        self.help_button = ttk.Button(self.delete_navsteva, text="Help", command=self.d_informace_navsteva)
        self.help_button.grid(row=0, column=1, columnspan=2, padx=5, pady=5)

    def zavri_insert_navsteva(self):
        """
        tato metoda zavře okno pro insert Navsteva
        :return:nevrací nic
        """
        self.insert_navsteva.destroy()

    def zavri_update_navsteva(self):
        """
        tato metoda zavře okno pro update Navsteva
        :return:nevrací nic
        """
        self.update_navsteva.destroy()

    def zavri_delete_navsteva(self):
        """
        tato metoda zavře okno pro delete Navsteva
        :return:nevrací nic
        """
        self.delete_navsteva.destroy()

    def i_informace_navsteva(self):
        messagebox.showinfo("Info","Pro úspěšný insert vyplňte správně všechny kolonky")

    def u_informace_navsteva(self):
        messagebox.showinfo("Info","Pro úspěšný update zvolte řádek, který chcete změnit a poté vyplňte správně kolonky")

    def d_informace_navsteva(self):
        messagebox.showinfo("Info","Pro úspěšný delete vyplňte správně název")

    def i_navsteva(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro insert Navsteva ošetří je regurelníma výrazama a poté je
        vloží do insert statementu pokud se insert provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        pokud uživatel zadá určitý atribut který musí být pro každý záznam unikátní tak na neho vyskočí okénko že musí
        být daný atribut unikátní
        :return: nevrací nic
        """
        i_datum_navsteva = self.datum_navsteva_entry.get()
        i_cena_navsteva = int(self.cena_navsteva_entry.get())
        i_id_pacient = int(self.id_pacient_entry.get())
        i_id_lekar = int(self.id_lekar_entry.get())
        i_id_nacini = int(self.id_nacini_entry.get())
        insert_statement = f"insert into navsteva(datum_navsteva, cena_navsteva, id_pacient, id_lekar, id_nacini) values(%s,%s,%s,%s,%s)"
        values = (i_datum_navsteva, i_cena_navsteva, i_id_pacient, i_id_lekar, i_id_nacini)

        self.cursor.execute(insert_statement, values)
        self.connection.commit()
        messagebox.showinfo("Insert", "Přidali jste do tabulky navsteva")
        self.zavri_insert_navsteva()


    def u_navsteva(self):
        """
        Tato metoda vezme zadané hodnoty z formuláře pro update Navsteva ošetří je regurelníma výrazama a poté je
        vloží do update statementu pokud se update provede vyskočí na uživatele okénko s informací že insert byl úspěšný
        a okno se zavře
        :return: nevraci nic
        """
        u_atribut = self.atribut_variable.get()
        u_uprava_atributu = self.uprava_atributu_entry.get()
        u_datum_navstevy = self.datum_navstevy_entry.get()

        update_statement = f"update navsteva set {u_atribut} = '{u_uprava_atributu}' where datum_navsteva = '{u_datum_navstevy}'"
        self.cursor.execute(update_statement)
        self.connection.commit()
        messagebox.showinfo("Update", "Upravili jste tabulku navsteva")
        self.zavri_update_navsteva()

    def d_navsteva(self):
        """
        Tato tabulka vezme datum navstevy z formuláře pro delete z tabulky Navsteva zkontroluje ho a dosadí ho do
        delete statementu a delete provede
        :return: nevraci nic
        """
        d_datum_navstevy = self.datum_navstevy_entry.get()

        delete_statement = f"delete from navsteva where datum_navsteva = '{d_datum_navstevy}'"
        self.cursor.execute(delete_statement)
        self.connection.commit()
        messagebox.showinfo("Delete", "Vymazali jste z tabulky navsteva")
        self.zavri_delete_navsteva()
