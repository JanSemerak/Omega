import json
def nacti_soubor():
    """metoda otevře konfigurační soubor poté ho projede for loopem po řádcích a vloží ho do proměné conf_text
    :return vráti promenou conf_text"""
    conf_text = ""
    try:
        conf = open("./config.conf", "r")
    except:
        raise Exception("Nelze nacist konfiguracni soubor")
    else:
        for line in conf:
            conf_text += line
        conf.close()
        return conf_text

def nacti_host():
    """Metoda načte metodu nacti soubor
    :return vrací host"""
    try:
        data = json.loads(nacti_soubor())
        return data['host']
    except:
        raise Exception("Nelze nacist from host z konfiguracniho souboru")

def nacti_user():
    """Metoda načte metodu nacti soubor
        :return vrací user"""
    try:
        data = json.loads(nacti_soubor())
        return data['user']
    except:
        raise Exception("Nelze nacist from user z konfiguracniho souboru")

def nacti_password():
    """Metoda načte metodu nacti soubor
        :return vrací password"""
    try:
        data = json.loads(nacti_soubor())
        return data['password']
    except:
        raise Exception("Nelze nacist from password z konfiguracniho souboru")

def nacti_databazi():
    """Metoda načte metodu nacti soubor
        :return vrací database"""
    try:
        data = json.loads(nacti_soubor())
        return data['database']
    except:
        raise Exception("Nelze nacist from database z konfiguracniho souboru")