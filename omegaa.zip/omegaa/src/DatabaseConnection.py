import mysql.connector
import Konfigurace

class DatabaseConnection:
    """
        Třída DatabaseConnection vytváří spojení s databází a poskytuje přístup k objektu spojení a kurzoru.

        Tato třída je navržena jako singleton, což znamená, že existuje pouze jedna instance této třídy v rámci aplikace.
        To zajišťuje konzistenci a sdílení stavu spojení s databází napříč aplikací.

        Metody:
        - __new__(): Vytváří novou instanci třídy DatabaseConnection, pokud žádná instance neexistuje, a inicializuje spojení s databází.
        - get_connection(): Vrací objekt spojení s databází.
        - get_cursor(): Vrací kurzor pro provádění dotazů v rámci spojení s databází.
    """
    _instance = None
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            host = Konfigurace.nacti_host()
            user = Konfigurace.nacti_user()
            password = Konfigurace.nacti_password()
            db = Konfigurace.nacti_databazi()
            cls._instance.connection = mysql.connector.connect(host=host, user=user, password=password, database=db)
            cls._instance.cursor = cls._instance.connection.cursor()
        return cls._instance

    def get_connection(self):
        """
           Vrací objekt spojení s databází.

           Returns:
           - connection: Objekt spojení s databází.
        """
        return self.connection
    def get_cursor(self):
        """
            Vrací kurzor pro provádění dotazů v rámci spojení s databází.

            Returns:
            - cursor: Kurzor pro provádění dotazů v rámci spojení s databází.
        """
        return self.cursor