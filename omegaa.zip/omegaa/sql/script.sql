create database omega;
use omega;

create table prihlaseni(
id int primary key auto_increment,
jmeno varchar(35) unique,
email varchar(35) unique,
telefon int(9) unique,
heslo varchar(35) unique
);

create table pojistovna(
id_pojistovna int PRIMARY KEY NOT NULL AUTO_INCREMENT,
nazev_pojistovna varchar(50) NOT NULL,
ulice_pojistovna varchar(50) NOT NULL,
mesto_pojistovna varchar(50) NOT NULL,
cislo_popisne_pojistovna int NOT NULL,
psc_pojistovna int NOT NULL
);

create table pacient(
id_pacient int PRIMARY KEY NOT NULL AUTO_INCREMENT,
  jmeno_pacient varchar(50) NOT NULL,
  prijmeni_pacient varchar(50) NOT NULL,
  rodne_cislo_pacient varchar(11) unique NOT NULL,
  telefonni_cislo_pacient varchar(9) unique NOT NULL,
  ulice_pacient varchar(50) NOT NULL,
  mesto_pacient varchar(50) NOT NULL,
  cislo_popisne_pacient int NOT NULL,
  psc_pacient int NOT NULL,
  id_pojistovna int not null,
  FOREIGN KEY (id_pojistovna) REFERENCES pojistovna(id_pojistovna)
);

create table nacini(
id_nacini int Primary Key NOT NULL AUTO_INCREMENT,
  nazev_nacini varchar(50) NOT NULL,
  kategorii_nacini varchar(50) NOT NULL,
vyrobce varchar(50) NOT NULL
);

create table oddeleni(
id_oddeleni int PRIMARY KEY NOT NULL AUTO_INCREMENT,
nazev_oddeleni varchar(50) NOT NULL,
telefonni_cislo_oddeleni varchar(9) unique NOT NULL,
patro_oddeleni int NOT NULL
);

create table navsteva(
 id_navsteva int PRIMARY KEY NOT NULL AUTO_INCREMENT,
datum_navsteva datetime NOT NULL,
  cena_navsteva float(8,2) DEFAULT NULL,
  id_pacient int not NULL,
  id_lekar int not NULL,
id_nacini int not NULL,
FOREIGN KEY (id_pacient) REFERENCES pacient(id_pacient),
FOREIGN KEY (id_lekar) REFERENCES lekar(id_lekar),
FOREIGN KEY (id_nacini) REFERENCES nacini(id_nacini)
);

create table lekar(
id_lekar int primary key NOT NULL AUTO_INCREMENT,
  jmeno_lekar varchar(50) NOT NULL,
  prijmeni_lekar varchar(50) NOT NULL,
  identifikacni_cislo_lekar varchar(5) unique NOT NULL,
  telefonni_cislo_lekar varchar(9) unique NOT NULL,
  id_oddeleni int not NULL,
  id_nemocnice int not null,
  FOREIGN KEY (id_oddeleni) REFERENCES oddeleni(id_oddeleni),
FOREIGN KEY (id_nemocnice) REFERENCES nemocnice(id_nemocnice)
);

create table nemocnice(
id_nemocnice int primary key NOT NULL AUTO_INCREMENT,
nazev_nemocnice varchar(50) NOT NULL,
ulice_nemocnice varchar(50) NOT NULL,
mesto_nemocnice varchar(50) NOT NULL,
cislo_popisne_nemocnice int NOT NULL,
psc_nemocnice int NOT NULL,
id_kafeterie int not null,
FOREIGN KEY (id_kafeterie) REFERENCES kafeterie(id_kafeterie)
);

create table kafeterie(
id_kafeterie int primary key NOT NULL AUTO_INCREMENT,
nazev_jidla varchar(50) not null,
cena int not null,
rozmer int not null,
pocet_zamestnancu int not null
);

INSERT INTO pojistovna (nazev_pojistovna,ulice_pojistovna,mesto_pojistovna,cislo_popisne_pojistovna,psc_pojistovna) VALUES ('OZP','Hlavní','Praha',123,12000),('VZP','Vedlejší','Brno',584,60300);
INSERT INTO pacient (jmeno_pacient,prijmeni_pacient ,  rodne_cislo_pacient,  telefonni_cislo_pacient,  ulice_pacient,mesto_pacient,  cislo_popisne_pacient,psc_pacient,  id_pojistovna) VALUES ('Jan','Semerák','102345/8752','728577259','Pražská','Praha',120,14200,1),('Petr','Veselý','798456/0120','963258741','Ostravská','Ostrava',287,74121,2);
INSERT INTO oddeleni(nazev_oddeleni ,telefonni_cislo_oddeleni ,patro_oddeleni) VALUES ('Chirurgie','604587896',3),('Ambulance','789321456',1);
INSERT INTO nacini(nazev_nacini ,kategorii_nacini ,vyrobce) VALUES ('Rentgen','Diagnostika','MedTech'),('Injekce','Terapie','Injection');
INSERT INTO kafeterie (nazev_jidla, cena, rozmer, pocet_zamestnancu) VALUES ('Hovězí guláš', 120, 250, 5),('Kuřecí salát', 90, 180, 3);
INSERT INTO nemocnice (nazev_nemocnice, ulice_nemocnice, mesto_nemocnice, cislo_popisne_nemocnice, psc_nemocnice, id_kafeterie)VALUES ('Nemocnice Na Slunci', 'Mladonická', 'Praha', 10, 12345, 1), ('Nemocnice U Jezera', 'Štilcovská', 'Brno', 20, 54321, 2);
INSERT INTO lekar(jmeno_lekar,prijmeni_lekar ,identifikacni_cislo_lekar ,telefonni_cislo_lekar ,id_oddeleni ,id_nemocnice) VALUES ('Martin','Novák','A1234','147528306',1,1),('Tomáš','Malý','B8754','602302605',2,2);
INSERT INTO navsteva(datum_navsteva,cena_navsteva ,id_pacient ,id_lekar,id_nacini) VALUES ('2024-02-02 10:30:00',150.00,1,1,1),('2023-07-13 14:45:00',0.00,2,2,2);
