-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: omega
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `kafeterie`
--

DROP TABLE IF EXISTS `kafeterie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kafeterie` (
  `id_kafeterie` int(11) NOT NULL AUTO_INCREMENT,
  `nazev_jidla` varchar(50) NOT NULL,
  `cena` int(11) NOT NULL,
  `rozmer` int(11) NOT NULL,
  `pocet_zamestnancu` int(11) NOT NULL,
  PRIMARY KEY (`id_kafeterie`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kafeterie`
--

LOCK TABLES `kafeterie` WRITE;
/*!40000 ALTER TABLE `kafeterie` DISABLE KEYS */;
INSERT INTO `kafeterie` VALUES (1,'Hovězí guláš',120,250,5),(2,'Kuřecí salát',90,180,3),(3,'s',1,1,1),(4,'s',1,1,1),(5,'s',1,1,3);
/*!40000 ALTER TABLE `kafeterie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lekar`
--

DROP TABLE IF EXISTS `lekar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lekar` (
  `id_lekar` int(11) NOT NULL AUTO_INCREMENT,
  `jmeno_lekar` varchar(50) NOT NULL,
  `prijmeni_lekar` varchar(50) NOT NULL,
  `identifikacni_cislo_lekar` varchar(5) NOT NULL,
  `telefonni_cislo_lekar` varchar(9) NOT NULL,
  `id_oddeleni` int(11) NOT NULL,
  `id_nemocnice` int(11) NOT NULL,
  PRIMARY KEY (`id_lekar`),
  UNIQUE KEY `identifikacni_cislo_lekar` (`identifikacni_cislo_lekar`),
  UNIQUE KEY `telefonni_cislo_lekar` (`telefonni_cislo_lekar`),
  KEY `id_oddeleni` (`id_oddeleni`),
  KEY `id_nemocnice` (`id_nemocnice`),
  CONSTRAINT `lekar_ibfk_1` FOREIGN KEY (`id_oddeleni`) REFERENCES `oddeleni` (`id_oddeleni`),
  CONSTRAINT `lekar_ibfk_2` FOREIGN KEY (`id_nemocnice`) REFERENCES `nemocnice` (`id_nemocnice`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lekar`
--

LOCK TABLES `lekar` WRITE;
/*!40000 ALTER TABLE `lekar` DISABLE KEYS */;
INSERT INTO `lekar` VALUES (1,'Martin','Novák','A1234','147528306',1,1),(2,'Tomáš','Malý','B8754','602302605',2,2),(3,'TomĂˇĹˇ','MalĂ˝','B8787','602302681',2,1),(5,'s','s','B8784','963874521',1,1);
/*!40000 ALTER TABLE `lekar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nacini`
--

DROP TABLE IF EXISTS `nacini`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nacini` (
  `id_nacini` int(11) NOT NULL AUTO_INCREMENT,
  `nazev_nacini` varchar(50) NOT NULL,
  `kategorii_nacini` varchar(50) NOT NULL,
  `vyrobce` varchar(50) NOT NULL,
  PRIMARY KEY (`id_nacini`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nacini`
--

LOCK TABLES `nacini` WRITE;
/*!40000 ALTER TABLE `nacini` DISABLE KEYS */;
INSERT INTO `nacini` VALUES (1,'Rentgen','Diagnostika','MedTech'),(2,'Injekce','Terapie','Injection');
/*!40000 ALTER TABLE `nacini` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navsteva`
--

DROP TABLE IF EXISTS `navsteva`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navsteva` (
  `id_navsteva` int(11) NOT NULL AUTO_INCREMENT,
  `datum_navsteva` datetime NOT NULL,
  `cena_navsteva` float(8,2) DEFAULT NULL,
  `id_pacient` int(11) NOT NULL,
  `id_lekar` int(11) NOT NULL,
  `id_nacini` int(11) NOT NULL,
  PRIMARY KEY (`id_navsteva`),
  KEY `id_pacient` (`id_pacient`),
  KEY `id_lekar` (`id_lekar`),
  KEY `id_nacini` (`id_nacini`),
  CONSTRAINT `navsteva_ibfk_1` FOREIGN KEY (`id_pacient`) REFERENCES `pacient` (`id_pacient`),
  CONSTRAINT `navsteva_ibfk_2` FOREIGN KEY (`id_lekar`) REFERENCES `lekar` (`id_lekar`),
  CONSTRAINT `navsteva_ibfk_3` FOREIGN KEY (`id_nacini`) REFERENCES `nacini` (`id_nacini`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navsteva`
--

LOCK TABLES `navsteva` WRITE;
/*!40000 ALTER TABLE `navsteva` DISABLE KEYS */;
INSERT INTO `navsteva` VALUES (1,'2024-02-02 10:30:00',150.00,1,1,1),(2,'2023-07-13 14:45:00',0.00,2,2,2);
/*!40000 ALTER TABLE `navsteva` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nemocnice`
--

DROP TABLE IF EXISTS `nemocnice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nemocnice` (
  `id_nemocnice` int(11) NOT NULL AUTO_INCREMENT,
  `nazev_nemocnice` varchar(50) NOT NULL,
  `ulice_nemocnice` varchar(50) NOT NULL,
  `mesto_nemocnice` varchar(50) NOT NULL,
  `cislo_popisne_nemocnice` int(11) NOT NULL,
  `psc_nemocnice` int(11) NOT NULL,
  `id_kafeterie` int(11) NOT NULL,
  PRIMARY KEY (`id_nemocnice`),
  KEY `id_kafeterie` (`id_kafeterie`),
  CONSTRAINT `nemocnice_ibfk_1` FOREIGN KEY (`id_kafeterie`) REFERENCES `kafeterie` (`id_kafeterie`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nemocnice`
--

LOCK TABLES `nemocnice` WRITE;
/*!40000 ALTER TABLE `nemocnice` DISABLE KEYS */;
INSERT INTO `nemocnice` VALUES (1,'Nemocnice Na Slunci','Mladonická','Praha',10,12345,1),(2,'Nemocnice U Jezera','Štilcovská','Brno',20,54321,2);
/*!40000 ALTER TABLE `nemocnice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oddeleni`
--

DROP TABLE IF EXISTS `oddeleni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oddeleni` (
  `id_oddeleni` int(11) NOT NULL AUTO_INCREMENT,
  `nazev_oddeleni` varchar(50) NOT NULL,
  `telefonni_cislo_oddeleni` varchar(9) NOT NULL,
  `patro_oddeleni` int(11) NOT NULL,
  PRIMARY KEY (`id_oddeleni`),
  UNIQUE KEY `telefonni_cislo_oddeleni` (`telefonni_cislo_oddeleni`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oddeleni`
--

LOCK TABLES `oddeleni` WRITE;
/*!40000 ALTER TABLE `oddeleni` DISABLE KEYS */;
INSERT INTO `oddeleni` VALUES (1,'Chirurgie','604587896',3),(2,'Ambulance','789321456',1),(4,'s','604587895',1);
/*!40000 ALTER TABLE `oddeleni` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pacient`
--

DROP TABLE IF EXISTS `pacient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pacient` (
  `id_pacient` int(11) NOT NULL AUTO_INCREMENT,
  `jmeno_pacient` varchar(50) NOT NULL,
  `prijmeni_pacient` varchar(50) NOT NULL,
  `rodne_cislo_pacient` varchar(11) NOT NULL,
  `telefonni_cislo_pacient` varchar(9) NOT NULL,
  `ulice_pacient` varchar(50) NOT NULL,
  `mesto_pacient` varchar(50) NOT NULL,
  `cislo_popisne_pacient` int(11) NOT NULL,
  `psc_pacient` int(11) NOT NULL,
  `id_pojistovna` int(11) NOT NULL,
  PRIMARY KEY (`id_pacient`),
  UNIQUE KEY `rodne_cislo_pacient` (`rodne_cislo_pacient`),
  UNIQUE KEY `telefonni_cislo_pacient` (`telefonni_cislo_pacient`),
  KEY `id_pojistovna` (`id_pojistovna`),
  CONSTRAINT `pacient_ibfk_1` FOREIGN KEY (`id_pojistovna`) REFERENCES `pojistovna` (`id_pojistovna`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pacient`
--

LOCK TABLES `pacient` WRITE;
/*!40000 ALTER TABLE `pacient` DISABLE KEYS */;
INSERT INTO `pacient` VALUES (1,'Jan','Semerák','102345/8752','728577259','Pražská','Praha',120,14200,1),(2,'Petr','Veselý','798456/0120','963258741','Ostravská','Ostrava',287,74121,2);
/*!40000 ALTER TABLE `pacient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pojistovna`
--

DROP TABLE IF EXISTS `pojistovna`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pojistovna` (
  `id_pojistovna` int(11) NOT NULL AUTO_INCREMENT,
  `nazev_pojistovna` varchar(50) NOT NULL,
  `ulice_pojistovna` varchar(50) NOT NULL,
  `mesto_pojistovna` varchar(50) NOT NULL,
  `cislo_popisne_pojistovna` int(11) NOT NULL,
  `psc_pojistovna` int(11) NOT NULL,
  PRIMARY KEY (`id_pojistovna`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pojistovna`
--

LOCK TABLES `pojistovna` WRITE;
/*!40000 ALTER TABLE `pojistovna` DISABLE KEYS */;
INSERT INTO `pojistovna` VALUES (1,'OZP','Hlavní','Praha',123,12000),(2,'VZP','Vedlejší','Brno',584,60300);
/*!40000 ALTER TABLE `pojistovna` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prihlaseni`
--

DROP TABLE IF EXISTS `prihlaseni`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prihlaseni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jmeno` varchar(35) DEFAULT NULL,
  `email` varchar(35) DEFAULT NULL,
  `telefon` int(9) DEFAULT NULL,
  `heslo` varchar(35) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `jmeno` (`jmeno`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `telefon` (`telefon`),
  UNIQUE KEY `heslo` (`heslo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prihlaseni`
--

LOCK TABLES `prihlaseni` WRITE;
/*!40000 ALTER TABLE `prihlaseni` DISABLE KEYS */;
INSERT INTO `prihlaseni` VALUES (1,'s','s@j.com',741986532,'s'),(3,'l','s@m.com',124578963,'h');
/*!40000 ALTER TABLE `prihlaseni` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-21 19:59:39
